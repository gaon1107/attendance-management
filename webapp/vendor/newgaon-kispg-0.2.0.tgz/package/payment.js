/**
 * [KISPG 공용 모듈 — 일반 결제 (결제창 인증 → 서버 승인 · 취소 · 조회)]
 * 파일: backend/lib/kispg/payment.js
 *
 * 규격 출처: KISPG 가맹점 연동가이드 v1.1.14
 *   ① 결제창 인증  POST {apiUrl}/v2/auth    (화면이 iframe 에 form 으로 엶, payReqType=1 → KIS 가 감싼 화면에 postMessage 로
 *                                            결과를 건네고 화면이 그 값을 returnUrl 로 POST — 2026-10-25 실결제 시험·KIS 샘플로 확인)
 *   ② 승인        POST {apiUrl}/v2/payment (서버끼리 JSON)
 *   ③ 취소        POST {apiUrl}/v2/cancel  (서버끼리 JSON, 암호값은 취소금액 기준)
 *   ④ 조회        POST {apiUrl}/v2/order   (서버끼리 JSON, 거래번호 또는 주문번호)
 *   ⑤ 결제통보    KIS 서버 → 우리 주소 (KISPG 결제통보 v1.0.4 — 가상계좌는 입금 때만 온다. 암호값 = mid + ediDate + amt + 상점키)
 *
 * 🔴 지켜야 할 것
 *   · 상점키(merchantKey)는 암호값을 만들 때만 쓰고, 결제창 값·결과 어디에도 넣지 않는다
 *   · 결제창 값·승인·취소·조회 모두 config.apiUrl 이 있어야 만든다/보낸다 (없으면 거절)
 *   · 승인 성공 코드여도 금액이 요청과 다르면 실패(amountMismatch)로 돌려준다 → 부르는 쪽이 즉시 취소
 *   · 결과를 모르는 실패(uncertain)는 부르는 쪽이 조회·취소로 정리한다
 *
 * 이 파일은 DB·환경변수를 모른다. 상점ID·상점키·KIS 주소는 부르는 쪽이 config 로 넘긴다.
 */

const { makeEncData, formatEdiDate, safeEqualHex } = require('./hash');
const { isAllowedApiUrl, joinUrl, requestKis } = require('./client');
const {
  CODES, isApprovalSuccess, isAnyApprovalSuccessCode, isCancelSuccess, isAlreadyCancelled, isNotFoundCode,
  isVacntReleaseSuccess, isVacntAlreadyDeposited
} = require('./codes');

// KIS 운영·시험 서버 주소 — 부르는 쪽이 둘 중 하나를 "명시적으로" config.apiUrl 에 넣어야 쓰인다
const LIVE_API_URL = 'https://api.kispg.co.kr';
const TEST_API_URL = 'https://testapi.kispg.co.kr';

const PATHS = Object.freeze({
  AUTH: '/v2/auth',
  APPROVE: '/v2/payment',
  CANCEL: '/v2/cancel',
  INQUIRE: '/v2/order'
});

// 결제창 결제수단 (연동가이드 3.1 payMethod) — 비우면 KIS 가 전체 수단을 보여 준다
const PAY_METHODS = Object.freeze(['CARD', 'BANK', 'VACNT', 'PHONE']);
const MODELS = Object.freeze(['WEB', 'MOB']);

// 상점ID: 제공된 mid (10 Byte 고정)
const MID_PATTERN = /^[A-Za-z0-9]{10}$/;
// 주문번호: 40바이트 이내, 우리 쪽은 영문·숫자·-·_ 만 쓴다 (KIS 쪽 유일값)
const ORDER_NO_PATTERN = /^[A-Za-z0-9_-]{1,40}$/;
// 금액: 숫자만, 15자리 이내
const AMOUNT_PATTERN = /^\d{1,15}$/;
// 휴대폰·전화번호 (숫자만, 0으로 시작 9~11자리)
const PHONE_PATTERN = /^0\d{8,10}$/;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// [byteLength] - UTF-8 바이트 수 (KIS 최대 크기는 바이트 기준. 한글 1자 = 3바이트로 보수적으로 센다)
function byteLength(value) {
  return Buffer.byteLength(String(value), 'utf8');
}

// [fitBytes] - 글자를 바이트 한도에 맞게 자른다 (글자 중간에서 자르지 않음)
// 파라미터: value(any), maxBytes(number)
// 반환값: string - 빈 값이면 ''
// @example fitBytes('가나다라마바사아자차카', 30) // '가나다라마바사아자차'
function fitBytes(value, maxBytes) {
  if (value === null || value === undefined) return '';
  let out = '';
  for (const ch of String(value)) {
    if (byteLength(out + ch) > maxBytes) break;
    out += ch;
  }
  return out;
}

// [readText] - 바깥에서 온 값을 문자열로 읽는다 (문자열·숫자만, 그 외는 '')
// 파라미터: value(any)
// 반환값: string - 앞뒤 공백 제거
function readText(value) {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return '';
}

// [toAmountText] - 금액을 KIS 형식(숫자 문자열)으로 바꾼다
// 파라미터: value(number|string), allowZero(boolean) - 공급가·부가세처럼 0 이 가능한 칸이면 true
// 반환값: string|null - 잘못된 값(소수·음수·쉼표·0)이면 null
function toAmountText(value, allowZero = false) {
  let text;
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value)) return null;
    text = String(value);
  } else if (typeof value === 'string') {
    text = value.trim();
  } else {
    return null;
  }
  if (!AMOUNT_PATTERN.test(text)) return null;
  if (!allowZero && Number(text) <= 0) return null;
  return String(Number(text));
}

// [toDueDate] - 가상계좌 입금 기한(lmtDay, yyyyMMdd)을 'YYYY-MM-DD' 로 (빈 값·'00000000'·없는 날짜면 null)
// 파라미터: value(any)
// 반환값: string|null - DB DATE 칸에 그대로 넣을 수 있는 값만 (잘못된 값으로 저장이 실패하지 않게 — 1단계 검수 메모 ①)
function toDueDate(value) {
  const text = readText(value);
  const m = /^(\d{4})(\d{2})(\d{2})/.exec(text);
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const date = new Date(Date.UTC(y, mo - 1, d));
  if (y < 2000 || date.getUTCFullYear() !== y || date.getUTCMonth() !== mo - 1 || date.getUTCDate() !== d) return null;
  return `${m[1]}-${m[2]}-${m[3]}`;
}

// [toAmountNumber] - KIS 응답 금액을 숫자로 (못 읽으면 null)
function toAmountNumber(value) {
  const text = readText(value);
  return AMOUNT_PATTERN.test(text) ? Number(text) : null;
}

// [assertConfig] - 상점 설정을 검사한다
// 파라미터: config({mid, merchantKey, apiUrl})
// 예외: 설정이 빠졌거나 주소가 허용되지 않으면 Error (한글)
function assertConfig(config) {
  const mid = config && readText(config.mid);
  // 상점키도 앞뒤 공백을 자른다 (.env 에 실수로 붙은 공백·공백뿐인 값을 일찍 잡는다 — 검수 L4)
  const merchantKey = config && typeof config.merchantKey === 'string' ? config.merchantKey.trim() : '';
  const apiUrl = config && readText(config.apiUrl);
  if (!mid || !merchantKey || !apiUrl) {
    throw new Error('결제 설정(상점ID·상점키·KIS 주소)이 없어 결제를 진행하지 않았습니다.');
  }
  if (!MID_PATTERN.test(mid)) {
    throw new Error('결제 설정의 상점ID 형식이 올바르지 않습니다.');
  }
  if (!isAllowedApiUrl(apiUrl)) {
    throw new Error('결제 설정의 KIS 주소가 https 가 아니어서 결제를 진행하지 않았습니다.');
  }
  return { mid, merchantKey, apiUrl };
}

// [checkBytes] - 선택 항목의 바이트 길이 검사 (있을 때만)
function checkBytes(value, maxBytes, label) {
  if (value !== '' && byteLength(value) > maxBytes) {
    throw new Error(`${label}이(가) 너무 깁니다. (최대 ${maxBytes}바이트)`);
  }
}

// [buildAuthRequest] - 결제창(KIS 인증)으로 보낼 form 값을 만든다 (순수 함수, 네트워크 없음)
// 파라미터: input.config({mid, merchantKey, apiUrl})
//           input.order - ordNo(주문번호), goodsNm(상품명), goodsAmt(결제금액, 원), ordNm(구매자명), ordTel(휴대폰),
//                         returnUrl(결과 받는 주소, https), payMethod(CARD/BANK/VACNT/PHONE, 비우면 전체),
//                         model(WEB/MOB, 기본 WEB), 선택: ordEmail, mbsUsrId, userIp, mbsIp, mbsReserved, period, channel,
//                         goodsSplAmt·goodsVat·goodsSvsAmt(부가세 '전송금액 기준' 상점만), crctType·crctNo(현금영수증)
//           input.now(Date, 선택) - 요청일시 기준 (시험용)
// 반환값: {action: string, fields: object} - 화면이 action 주소로 fields 를 iframe 에 form POST 한다 (_self 로 넘기면 결과를 받을 곳이 없어 KIS 빈 화면에서 멈춤)
// 예외: 입력이 잘못되면 Error 를 던진다 (한글). 부르는 쪽이 잡아서 사용자 안내로 바꾼다
function buildAuthRequest(input) {
  const { config, now } = input || {};
  const order = input && input.order && typeof input.order === 'object' ? input.order : {};
  const { mid, merchantKey, apiUrl } = assertConfig(config);

  const ordNo = readText(order.ordNo);
  if (!ORDER_NO_PATTERN.test(ordNo)) throw new Error('주문번호는 영문·숫자·-·_ 로 40자 이내여야 합니다.');

  const goodsNm = readText(order.goodsNm);
  if (goodsNm === '') throw new Error('상품명이 없습니다.');
  checkBytes(goodsNm, 100, '상품명');

  const goodsAmt = toAmountText(order.goodsAmt);
  if (!goodsAmt) throw new Error('결제 금액이 올바르지 않습니다. (1원 이상 정수)');

  const ordNm = readText(order.ordNm);
  if (ordNm === '') throw new Error('구매자명이 없습니다.');
  checkBytes(ordNm, 30, '구매자명');

  const ordTel = readText(order.ordTel).replace(/[^0-9]/g, '');
  if (!PHONE_PATTERN.test(ordTel)) throw new Error('구매자 전화번호 형식이 올바르지 않습니다.');

  const returnUrl = readText(order.returnUrl);
  if (!isAllowedApiUrl(returnUrl) || byteLength(returnUrl) > 255) {
    throw new Error('결과 받는 주소는 https 로 시작하고 255자 이내여야 합니다. (내 컴퓨터 시험 주소만 http 허용)');
  }

  const payMethod = readText(order.payMethod).toUpperCase();
  if (payMethod !== '' && !PAY_METHODS.includes(payMethod)) throw new Error('결제수단이 올바르지 않습니다.');

  const model = readText(order.model).toUpperCase() || 'WEB';
  if (!MODELS.includes(model)) throw new Error('결제창 모델은 WEB 또는 MOB 이어야 합니다.');

  const ediDate = formatEdiDate(now instanceof Date ? now : new Date());

  const fields = {};
  if (payMethod !== '') fields.payMethod = payMethod;
  Object.assign(fields, {
    trxCd: '0',               // 0 = 일반 (에스크로 아님)
    mid,
    goodsNm,
    currencyType: 'KRW',
    ordNo,
    goodsAmt,
    ordNm,
    ordTel,
    returnUrl,
    ediDate,
    encData: makeEncData(mid, ediDate, goodsAmt, merchantKey),
    model,
    charset: 'UTF-8',
    payReqType: '1'           // 1 = 인증 결과를 returnUrl 로 받고, 승인은 우리 서버가 따로 요청
  });

  // 선택 항목 — 값이 있을 때만 넣는다
  const optional = [
    ['ordEmail', 60, '구매자 이메일'], ['mbsUsrId', 20, '상점 사용자 아이디'], ['userIp', 20, '사용자 IP'],
    ['mbsIp', 20, '상점 IP'], ['mbsReserved', 500, '상점 예약필드'], ['period', 21, '제공기간'], ['channel', 4, '접속타입']
  ];
  for (const [key, maxBytes, label] of optional) {
    const value = readText(order[key]);
    checkBytes(value, maxBytes, label);
    if (value !== '') fields[key] = value;
  }
  if (fields.ordEmail && !EMAIL_PATTERN.test(fields.ordEmail)) throw new Error('구매자 이메일 형식이 올바르지 않습니다.');

  for (const key of ['goodsSplAmt', 'goodsVat', 'goodsSvsAmt']) {
    if (order[key] === undefined || order[key] === null || order[key] === '') continue;
    const value = toAmountText(order[key], true);
    if (value === null) throw new Error('공급가·부가세·봉사료는 0 이상의 정수여야 합니다.');
    fields[key] = value;
  }

  const crctType = readText(order.crctType);
  if (crctType !== '') {
    if (!['0', '1', '2'].includes(crctType)) throw new Error('현금영수증 구분은 0·1·2 중 하나여야 합니다.');
    fields.crctType = crctType;
  }
  const crctNo = readText(order.crctNo).replace(/[^0-9]/g, '');
  if (crctNo !== '') {
    if (crctNo.length > 15) throw new Error('현금영수증 번호가 너무 깁니다.');
    fields.crctNo = crctNo;
  }

  return { action: joinUrl(apiUrl, PATHS.AUTH), fields };
}

// [parseAuthResult] - 결제창이 returnUrl 로 보낸 인증 결과를 읽는다 (순수 함수)
// 파라미터: body(object) - form 으로 받은 값 (express.urlencoded 결과)
// 반환값: {ok, resultCd, resultMsg, payMethod, tid, ordNo, amt, ediDate, encData, mbsReserved}
//   ok = 인증 성공(0000) + 거래번호 있음. 아직 돈이 빠진 것이 아니다 → approve 를 불러야 결제된다
function parseAuthResult(body) {
  const src = body && typeof body === 'object' ? body : {};
  const result = {
    resultCd: readText(src.resultCd),
    resultMsg: readText(src.resultMsg),
    payMethod: readText(src.payMethod).toUpperCase(),
    tid: readText(src.tid),
    ordNo: readText(src.ordNo),
    amt: readText(src.amt),
    ediDate: readText(src.ediDate),
    encData: readText(src.encData),
    mbsReserved: readText(src.mbsReserved)
  };
  result.ok = result.resultCd === CODES.AUTH_SUCCESS && result.tid !== '';
  return result;
}

// [verifyAuthResult] - 인증 결과의 암호값이 맞는지 검사한다 (위변조 확인)
// 파라미터: input.config({mid, merchantKey, apiUrl}), input.result(parseAuthResult 결과)
// 반환값: boolean - 맞으면 true. 설정이 없거나 값이 비면 false
// ⚠️ 응답 암호값 계산식은 KIS 문서에 없다. 요청과 같은 식(mid + ediDate + amt + 상점키)으로 가정했다.
//    KIS 회신(2026-10-17 메일 2번)·5단계 실제 시험으로 확정하기 전까지, 부르는 쪽은 이 값만으로 결제를 막지 말고
//    "금액·주문번호를 DB 주문서와 대조 + 승인 응답 금액 확인"을 주된 검사로 쓴다.
function verifyAuthResult(input) {
  const { config, result } = input || {};
  let settings;
  try {
    settings = assertConfig(config);
  } catch (_) {
    return false;
  }
  if (!result || !result.ediDate || !result.amt || !result.encData) return false;
  const expected = makeEncData(settings.mid, result.ediDate, result.amt, settings.merchantKey);
  return safeEqualHex(expected, result.encData);
}

// [parseNotification] - KIS 결제통보(입금 알림)를 읽는다 (순수 함수 — 결제통보 v1.0.4 5.1)
// 파라미터: body(object) - form 으로 받은 값 (express.urlencoded 결과)
// 반환값: {resultCd, resultMsg, payMethod, tid, appDtm, appNo, ordNo, amt(원문), amtNumber(숫자|null), fnNm, cancelYN,
//          vacntNo, lmtDay, dueDate, ediDate, encData, mid, orgTid, remainAmt, cashCrctFlg}
//   통보 자체는 위조될 수 있다 → verifyNotification(암호값)·보낸 곳 IP·DB 주문 대조를 모두 거친 뒤에만 믿는다
function parseNotification(body) {
  const src = body && typeof body === 'object' ? body : {};
  const amt = readText(src.amt);
  return {
    resultCd: readText(src.resultCd),
    resultMsg: readText(src.resultMsg),
    payMethod: readText(src.payMethod).toUpperCase(),
    tid: readText(src.tid),
    appDtm: readText(src.appDtm),
    appNo: readText(src.appNo),
    ordNo: readText(src.ordNo),
    amt,
    amtNumber: toAmountNumber(amt),
    fnNm: readText(src.fnNm),
    cancelYN: readText(src.cancelYN).toUpperCase(),
    vacntNo: readText(src.vacntNo),
    lmtDay: readText(src.lmtDay),
    dueDate: toDueDate(src.lmtDay),
    ediDate: readText(src.ediDate),
    encData: readText(src.encData),
    mid: readText(src.mid),
    orgTid: readText(src.orgTid),
    remainAmt: readText(src.remainAmt),
    cashCrctFlg: readText(src.cashCrctFlg)
  };
}

// [verifyNotification] - 결제통보의 암호값이 맞는지 검사한다 (위변조 확인 — 결제통보 v1.0.4 6장)
// 파라미터: input.config({mid, merchantKey, apiUrl}), input.noti(parseNotification 결과)
// 반환값: boolean - 통보의 상점ID 가 설정과 같고 SHA256(mid + ediDate + amt + 상점키) 가 encData 와 같을 때만 true
//   KIS 샘플은 이 검사를 하지 않지만 문서는 "반드시 검증"이라 적혀 있다 — 따라 하지 않는다
function verifyNotification(input) {
  const { config, noti } = input || {};
  let settings;
  try {
    settings = assertConfig(config);
  } catch (_) {
    return false;
  }
  if (!noti || noti.mid !== settings.mid || !noti.ediDate || !noti.amt || !noti.encData) return false;
  const expected = makeEncData(settings.mid, noti.ediDate, noti.amt, settings.merchantKey);
  return safeEqualHex(expected, noti.encData);
}

// [failure] - 요청 전에 막힌 실패 결과 (KIS 에 보내지 않았으므로 결과가 확정)
function failure(error, extra = {}) {
  return { ok: false, uncertain: false, resultCd: '', resultMsg: '', error, ...extra };
}

// [approve] - 인증된 거래의 승인을 요청한다 (실제로 돈이 빠지는 단계)
// 파라미터: input.config, input.tid(인증 결과 거래번호), input.goodsAmt(우리 DB 주문서의 금액 — 인증 결과 금액이 아님),
//           input.ordNo(선택, 우리 DB 주문서의 주문번호 — 넘기면 응답 주문번호와 대조), input.now(선택)
//           options.transport·options.timeoutMs (시험용)
// 반환값: Promise<{
//   ok, uncertain, amountMismatch, resultCd, resultMsg, payMethod, tid, appNo, appDtm, ordNo, amt,
//   fnNm, cardNo(가려진 번호), cardType, quota, appCardCd, acqCardCd, easyPayCd, easyPayNm, cancelYN,
//   vacntNo(가상계좌 번호), lmtDay(입금 기한 원문), dueDate(입금 기한 'YYYY-MM-DD' 또는 null), error
// }>
//   가상계좌(VACNT)는 ok=true 가 "계좌 발급 성공(4100)"이다 — 돈은 아직 들어오지 않았다 (입금 알림을 기다린다)
//   amountMismatch=true → 승인은 났지만 금액이 다름: 부르는 쪽이 amt(실제 승인 금액)로 즉시 취소
//   uncertain=true      → 돈이 빠졌는지 모름: 부르는 쪽이 inquire 로 확인
// 예외를 던지지 않는다
async function approve(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  const { config, now } = src;
  let settings;
  try {
    settings = assertConfig(config);
  } catch (err) {
    return failure(err.message);
  }
  const tid = readText(src.tid);
  if (tid === '' || tid.length > 30) return failure('거래번호가 올바르지 않습니다.');
  const goodsAmt = toAmountText(src.goodsAmt);
  if (!goodsAmt) return failure('결제 금액이 올바르지 않습니다.');
  const expectedOrdNo = readText(src.ordNo);

  const ediDate = formatEdiDate(now instanceof Date ? now : new Date());
  const body = {
    mid: settings.mid,
    tid,
    goodsAmt,
    ediDate,
    encData: makeEncData(settings.mid, ediDate, goodsAmt, settings.merchantKey),
    charset: 'UTF-8'
  };

  const response = await requestKis(joinUrl(settings.apiUrl, PATHS.APPROVE), body, options);
  if (!response.ok) {
    return { ok: false, uncertain: response.uncertain, resultCd: '', resultMsg: '', tid, error: response.error };
  }

  const data = response.data;
  const resultCd = readText(data.resultCd);
  // 응답에 결제수단이 없으면 성공 코드로 수단을 짐작한다 (3001 카드 / 4000 계좌이체 / 4100 가상계좌 발급)
  let payMethod = readText(data.payMethod).toUpperCase();
  if (payMethod === '') {
    if (resultCd === CODES.CARD_SUCCESS) payMethod = 'CARD';
    else if (resultCd === CODES.BANK_SUCCESS) payMethod = 'BANK';
    else if (resultCd === CODES.VACNT_ISSUED) payMethod = 'VACNT';
  }
  const amt = toAmountNumber(data.amt);
  const responseTid = readText(data.tid);
  const result = {
    ok: false,
    uncertain: false,
    amountMismatch: false,
    resultCd,
    resultMsg: readText(data.resultMsg),
    payMethod,
    tid: responseTid || tid,
    appNo: readText(data.appNo),
    appDtm: readText(data.appDtm),
    ordNo: readText(data.ordNo),
    amt,
    fnNm: readText(data.fnNm),
    cardNo: readText(data.cardNo),
    cardType: readText(data.cardType),
    quota: readText(data.quota),
    appCardCd: readText(data.appCardCd),
    acqCardCd: readText(data.acqCardCd),
    easyPayCd: readText(data.easyPayCd),
    easyPayNm: readText(data.easyPayNm),
    cancelYN: readText(data.cancelYN),
    vacntNo: readText(data.vacntNo),
    lmtDay: readText(data.lmtDay),
    dueDate: toDueDate(data.lmtDay),
    error: null
  };

  if (!isApprovalSuccess(payMethod, resultCd)) {
    // 🔴 성공 코드(3001·4000·4100)인데 결제수단 이름만 예상과 다르면(간편결제 등) 돈이 빠졌을 수 있다 → 결과 모름 (검수 C2)
    if (isAnyApprovalSuccessCode(resultCd)) {
      result.uncertain = true;
      result.error = `승인 성공 코드(${resultCd})이지만 결제수단(${payMethod || '없음'})이 예상과 달라 확인이 필요합니다.`;
      return result;
    }
    result.error = result.resultMsg || `결제가 승인되지 않았습니다. (코드 ${resultCd || '없음'})`;
    return result;
  }
  // 🔴 응답이 우리가 요청한 거래·주문의 것인지 확인 — 다르면 어느 거래가 승인됐는지 모른다 (검수 M2)
  if (responseTid !== '' && responseTid !== tid) {
    result.uncertain = true;
    result.error = `승인 응답의 거래번호가 요청과 다릅니다. (요청 ${tid}, 응답 ${responseTid})`;
    return result;
  }
  if (expectedOrdNo !== '' && result.ordNo !== '' && result.ordNo !== expectedOrdNo) {
    result.uncertain = true;
    result.error = `승인 응답의 주문번호가 주문서와 다릅니다. (주문서 ${expectedOrdNo}, 응답 ${result.ordNo})`;
    return result;
  }
  // 🔴 성공 코드여도 금액이 다르면 받지 않는다 — 부르는 쪽이 이 거래를 즉시 취소해야 한다
  if (amt !== Number(goodsAmt)) {
    result.amountMismatch = true;
    result.error = `승인 금액이 주문 금액과 다릅니다. (주문 ${goodsAmt}원, 승인 ${amt === null ? '알 수 없음' : `${amt}원`})`;
    return result;
  }
  result.ok = true;
  return result;
}

// 요청 전에 막힌 취소 실패에 붙이는 칸
const NOT_CANCELLED = Object.freeze({ alreadyCancelled: false, released: false, alreadyDeposited: false });

// [cancel] - 승인된 거래를 취소한다 (전체 또는 부분)
// 파라미터: input.config, input.tid, input.payMethod(CARD/BANK…), input.canAmt(취소금액), input.canMsg(취소사유, 필수),
//           선택: input.partCanFlg('0' 전체 기본 / '1' 부분), ordNo, canId, canNm, canIp, now
//           options.transport·options.timeoutMs (시험용)
// 반환값: Promise<{ok, uncertain, alreadyCancelled, released, alreadyDeposited, resultCd, resultMsg, tid, amt, cancelYN, appDtm, error}>
//   가상계좌 입금 전 발급 취소는 발급 거래번호 + VACNT + 전액 + 환불계좌 칸 없이 보낸다 (KIS 10-30) → 성공이면 released=true (4200)
//   alreadyDeposited=true(3109) → 그사이 입금됨: 취소되지 않았다 (부르는 쪽이 입금 반영 쪽으로)
// 예외를 던지지 않는다
async function cancel(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  const { config, now } = src;
  let settings;
  try {
    settings = assertConfig(config);
  } catch (err) {
    return failure(err.message, NOT_CANCELLED);
  }
  const tid = readText(src.tid);
  if (tid === '' || tid.length > 30) return failure('거래번호가 올바르지 않습니다.', NOT_CANCELLED);
  const payMethod = readText(src.payMethod).toLowerCase();
  if (!PAY_METHODS.includes(payMethod.toUpperCase())) return failure('결제수단이 올바르지 않습니다.', NOT_CANCELLED);
  const canAmt = toAmountText(src.canAmt);
  if (!canAmt) return failure('취소 금액이 올바르지 않습니다.', NOT_CANCELLED);
  const canMsg = readText(src.canMsg);
  if (canMsg === '') return failure('취소 사유가 없습니다.', NOT_CANCELLED);
  const partCanFlg = readText(src.partCanFlg) || '0';
  if (!['0', '1'].includes(partCanFlg)) return failure('부분취소 구분이 올바르지 않습니다.', NOT_CANCELLED);

  const ediDate = formatEdiDate(now instanceof Date ? now : new Date());
  const body = {
    payMethod,                     // 취소 규격은 소문자 (card, bank, vacnt, phone)
    tid,
    mid: settings.mid,
    canAmt,
    canMsg: fitBytes(canMsg, 100),
    partCanFlg,
    ediDate,
    encData: makeEncData(settings.mid, ediDate, canAmt, settings.merchantKey),
    charset: 'UTF-8'
  };
  const ordNo = readText(src.ordNo);
  if (ordNo !== '') body.ordNo = ordNo;
  const canId = fitBytes(readText(src.canId), 20);
  if (canId !== '') body.canId = canId;
  const canNm = fitBytes(readText(src.canNm), 30);
  if (canNm !== '') body.canNm = canNm;
  const canIp = readText(src.canIp);
  if (canIp !== '' && byteLength(canIp) <= 20) body.canIp = canIp;

  const response = await requestKis(joinUrl(settings.apiUrl, PATHS.CANCEL), body, options);
  if (!response.ok) {
    return { ok: false, uncertain: response.uncertain, ...NOT_CANCELLED, resultCd: '', resultMsg: '', tid, error: response.error };
  }
  const data = response.data;
  const resultCd = readText(data.resultCd);
  // 가상계좌는 입금 전 해제(4200)도 취소 성공 — 카드·계좌이체에는 4200 을 성공으로 보지 않는다
  const released = payMethod === 'vacnt' && isVacntReleaseSuccess(resultCd);
  const result = {
    ok: isCancelSuccess(resultCd) || released,
    uncertain: false,
    alreadyCancelled: isAlreadyCancelled(resultCd),
    released,
    alreadyDeposited: payMethod === 'vacnt' && isVacntAlreadyDeposited(resultCd),
    resultCd,
    resultMsg: readText(data.resultMsg),
    tid: readText(data.tid) || tid,
    amt: toAmountNumber(data.amt),
    cancelYN: readText(data.cancelYN),
    appDtm: readText(data.appDtm),
    error: null
  };
  if (!result.ok) {
    result.error = result.resultMsg || `취소되지 않았습니다. (코드 ${resultCd || '없음'})`;
    return result;
  }
  // 전체 취소 성공인데 응답 금액이 요청과 다르면 얼마가 취소됐는지 모른다 → 결과 모름 (검수 L6)
  // 부분 취소는 응답 금액(amt "거래금액")이 원래 결제 금액일 수 있어 대조하지 않는다 (규격 불명확)
  if (partCanFlg === '0' && result.amt !== null && result.amt !== Number(canAmt)) {
    result.ok = false;
    result.uncertain = true;
    result.error = `취소 응답 금액이 요청과 다릅니다. (요청 ${canAmt}원, 응답 ${result.amt}원)`;
  }
  return result;
}

// KIS 조회 결제상태(trxStatus) → 우리 쪽 값 (바깥 값이 키가 되므로 프로토타입 없는 표 — toString 같은 이름 방지)
//   가상계좌: '승인' = 입금 완료, '입금대기' = 발급 후 입금 전(기한이 지나도 계속 '입금대기' — 기한은 lmtDay 로 판단),
//            '발급취소' = 입금 전 해제됨(돈이 들어온 적 없음) → 취소와 같이 본다 (KIS 10-30)
const TRX_STATUS = Object.freeze(Object.assign(Object.create(null), {
  '승인': 'approved', '취소': 'cancelled', '입금대기': 'waiting', '발급취소': 'cancelled'
}));

// [inquire] - 결제 상태를 조회한다 (승인 응답을 못 받았을 때 "돈이 빠졌는지" 확인용)
// 파라미터: input.config, input.tid 또는 input.ordNo(둘 중 하나 필수, 둘 다 있으면 KIS 는 거래번호 기준),
//           input.goodsAmt(주문 금액), input.now(선택), input.vacnt(선택, 가상계좌 주문이면 true)
//           input.vacntNo(선택, 발급받은 가상계좌 번호 — 넘기면 금액 없는 '승인' 응답을 발급 금액 입금으로 확정, amtFromOrder=true)
//           options.transport·options.timeoutMs (시험용)
//   vacnt=true: 입금된 가상계좌는 응답 거래번호가 입금 거래번호(발급 번호와 다름 — KIS 10-30)일 수 있다
//               → 주문번호가 같고 '승인'이면 확정으로 보고 depositTid 에 응답 거래번호를 돌려준다
// 반환값: Promise<{
//   found, status('approved'|'cancelled'|'waiting'|'not_found'|'unknown'), uncertain, amountMismatch,
//   resultCd, resultMsg, tid, ordNo, amt, payMethod, appNo, appDtm, cancelYN, cancelData,
//   trxStatus(KIS 원문), vacntNo·fnNm·lmtDay·dueDate(가상계좌), depositTid(가상계좌 입금 거래번호 후보), error
// }>
//   status='not_found' 는 KIS 가 "미승인"(OR01 결제 미완료·OR02 주문 없음·6505)으로 확인해 줄 때만
//   status='unknown' + uncertain=true 면 상태를 확정하지 못한 것 → 나중에 다시 조회한다 (실패로 단정 금지)
//   amountMismatch=true → 승인됐지만 금액이 다름: amt(실제 승인 금액)로 취소
// 예외를 던지지 않는다
async function inquire(input, options) {
  // 🔴 조회의 약속: "돈이 안 빠졌다"고 볼 수 있는 것은 status='not_found' 하나뿐.
  //    설정 오류·연결 거부·요청 거절처럼 조회를 못 한 경우도 원래 결제는 여전히 모르는 상태 → 항상 uncertain=true (재검수 M-3)
  const unknown = (error) => ({
    found: false, status: 'unknown', uncertain: true, amountMismatch: false, resultCd: '', resultMsg: '', tid: '', ordNo: '',
    amt: null, payMethod: '', appNo: '', appDtm: '', cancelYN: '', cancelData: '',
    trxStatus: '', vacntNo: '', fnNm: '', lmtDay: '', dueDate: null, depositTid: '', error
  });
  const src = input && typeof input === 'object' ? input : {};
  const { config, now } = src;
  let settings;
  try {
    settings = assertConfig(config);
  } catch (err) {
    return unknown(err.message);
  }
  const tid = readText(src.tid);
  const ordNo = readText(src.ordNo);
  if (tid === '' && ordNo === '') return unknown('거래번호나 주문번호가 필요합니다.');
  const goodsAmt = toAmountText(src.goodsAmt);
  if (!goodsAmt) return unknown('결제 금액이 올바르지 않습니다.');

  const ediDate = formatEdiDate(now instanceof Date ? now : new Date());
  const body = {
    mid: settings.mid,
    goodsAmt,
    ediDate,
    encData: makeEncData(settings.mid, ediDate, goodsAmt, settings.merchantKey)
  };
  if (tid !== '') body.tid = tid;
  if (ordNo !== '') body.ordNo = ordNo;

  const response = await requestKis(joinUrl(settings.apiUrl, PATHS.INQUIRE), body, options);
  if (!response.ok) return unknown(response.error);

  const data = response.data;
  const trxStatus = readText(data.trxStatus);
  const result = {
    found: trxStatus !== '',
    status: 'unknown',
    uncertain: false,
    amountMismatch: false,
    resultCd: readText(data.resultCd),
    resultMsg: readText(data.resultMsg),
    tid: readText(data.tid),
    ordNo: readText(data.ordNo),
    amt: toAmountNumber(data.amt),
    payMethod: readText(data.payMethod).toUpperCase(),
    appNo: readText(data.appNo),
    appDtm: readText(data.appDtm),
    cancelYN: readText(data.cancelYN),
    cancelData: readText(data.cancelData),
    trxStatus,
    vacntNo: readText(data.vacntNo),
    fnNm: readText(data.fnNm),
    lmtDay: readText(data.lmtDay),
    dueDate: toDueDate(data.lmtDay),
    depositTid: '',
    error: null
  };

  if (!result.found) {
    // 🔴 "결제 없음"은 KIS 가 확인해 준 코드일 때만. 그 밖의 오류는 돈이 빠졌는지 모르는 상태 (검수 C1)
    if (isNotFoundCode(result.resultCd)) {
      result.status = 'not_found';
      result.error = result.resultMsg || '결제 내역이 없습니다.';
    } else {
      result.uncertain = true;
      result.error = `결제 상태를 확인하지 못했습니다. (코드 ${result.resultCd || '없음'}${result.resultMsg ? ` ${result.resultMsg}` : ''})`;
    }
    return result;
  }
  // 응답이 우리가 물어본 거래·주문의 것인지 확인 (KIS 는 둘 다 보내면 거래번호 기준으로 찾는다 — 검수 M1)
  //   가상계좌 입금 완료는 거래번호가 입금 거래번호로 달라질 수 있다 → 주문번호가 같고 '승인'이면 확정 (가상계좌 2단계 검수 중간 3)
  const vacntDeposit = src.vacnt === true && trxStatus === '승인' && ordNo !== '' && result.ordNo === ordNo;
  if (vacntDeposit && tid !== '' && result.tid !== '' && result.tid !== tid) result.depositTid = result.tid;
  if ((tid !== '' && result.tid !== '' && result.tid !== tid && !vacntDeposit)
    || (ordNo !== '' && result.ordNo !== '' && result.ordNo !== ordNo)) {
    result.uncertain = true;
    result.error = '조회 응답의 거래번호·주문번호가 요청과 다릅니다.';
    return result;
  }
  if (!Object.prototype.hasOwnProperty.call(TRX_STATUS, trxStatus)) {
    // 표에 없는 상태(예: 부분취소 등) — 부르는 쪽이 해석할 수 없으므로 확정으로 보지 않는다
    result.uncertain = true;
    result.error = `알 수 없는 결제 상태입니다. (${trxStatus})`;
    return result;
  }
  result.status = TRX_STATUS[trxStatus];
  // KIS 승인 기준은 "승인이면서 취소 아님(cancelYN=N)" (KIS 10-19 회신) — 승인인데 취소 표시(Y)면 앞뒤가 맞지 않는다
  //   (통신이 끊겨 KIS 가 자동 취소한 결제일 수 있음) → 승인으로 보고 기간을 늘리지도, 실패로 닫지도 않는다 (대기목록 R46)
  if (result.status === 'approved' && result.cancelYN.toUpperCase() === 'Y') {
    result.uncertain = true;
    result.error = '조회 결과가 승인이지만 취소 표시(cancelYN=Y)가 있어 확인이 필요합니다.';
    return result;
  }
  // 가상계좌 입금 조회는 KIS 가 금액·거래번호·결제수단 칸을 보내지 않는다 (운영 실측 2026-10-30, 항목 10개 — BUG-050)
  //   부르는 쪽이 발급받은 계좌번호를 넘겼고 응답 계좌번호·주문번호가 같은 '승인'이면 발급 금액으로 입금된 것으로 본다
  //   근거: 가상계좌는 발급 금액과 다른 금액을 은행이 거절한다 (KIS 10-30 회신). 계좌번호를 안 넘긴 호출은 예전처럼 결과 모름
  const vacntNoAsked = readText(src.vacntNo);
  if (vacntDeposit && result.amt === null && vacntNoAsked !== '' && result.vacntNo === vacntNoAsked) {
    result.amt = Number(goodsAmt);
    result.amtFromOrder = true;
  }
  // 승인 상태인데 금액이 주문 금액과 다르면 알려 준다 → 부르는 쪽이 amt(실제 승인 금액)로 취소
  if (result.status === 'approved' && result.amt === null) {
    // 승인이라는데 금액을 알 수 없다 → 금액 확인 없이 이용 기간을 늘리면 안 된다 (재검수 M-1)
    result.uncertain = true;
    result.error = '조회 결과에 승인 금액이 없어 확인이 필요합니다.';
    return result;
  }
  if (result.status === 'approved' && result.amt !== Number(goodsAmt)) {
    result.amountMismatch = true;
    result.error = `승인 금액이 주문 금액과 다릅니다. (주문 ${goodsAmt}원, 승인 ${result.amt}원)`;
  }
  return result;
}

module.exports = {
  LIVE_API_URL,
  TEST_API_URL,
  PATHS,
  PAY_METHODS,
  fitBytes,
  buildAuthRequest,
  parseAuthResult,
  verifyAuthResult,
  parseNotification,
  verifyNotification,
  approve,
  cancel,
  inquire,
  // 같은 모듈 안(billing.js)에서만 쓰는 도우미 — index.js 로 공개하지 않는다
  internal: Object.freeze({
    ORDER_NO_PATTERN, PHONE_PATTERN, EMAIL_PATTERN,
    byteLength, readText, toAmountText, toAmountNumber, toDueDate, assertConfig, failure
  })
};
