/**
 * [KISPG 공용 모듈 — 자동결제(빌링): 카드 등록 · 빌키 결제 · 취소 · 삭제 · 유효 확인]
 * 파일: backend/lib/kispg/billing.js
 *
 * KISPG_자동결제_수정계획서_20261020.md 1단계 (2026-10-20, 사장님 "추천대로, 1단계 진행")
 * 규격 출처: KISPG 빌링 가이드 v1.0.10 + KIS 2차 회신(2026-10-19) 3·4·5·8번 + 빌링 예제 코드
 *   ① 카드 등록 결제창  POST {apiUrl}/v2/auth             (일반 결제창과 같은 값·같은 iframe+postMessage 방식, 결제수단은 카드만, payReqType=1)
 *   ② 카드 등록 확정    POST {apiUrl}/v2/payment          (서버끼리 JSON — 응답에 빌키 bid. 돈은 빠지지 않는다)
 *   ③ 빌키 결제        POST {apiUrl}/v2/billing/payment  (실제로 돈이 빠지는 단계. 첫 결제·정기결제 모두)
 *   ④ 빌키 결제 취소    POST {apiUrl}/v2/billing/cancel   (암호값은 취소금액 기준 — KIS 회신 5번)
 *   ⑤ 빌키 삭제        POST {apiUrl}/v2/billing/delete   (암호값은 빌키 기준. 한 번 지우면 되살릴 수 없다)
 *   ⑥ 빌키 유효 확인    POST {apiUrl}/v2/billing/validate (암호값은 빌키 기준 — 문서의 "9.4 참조"는 오기, KIS 회신 5번)
 *   결과를 모를 때의 확인은 일반 결제와 같은 조회(payment.js inquire, /v2/order) — 자동결제 승인도 조회된다(KIS 8번)
 *
 * 🔴 지켜야 할 것
 *   · 자동결제는 별도 상점ID·상점키(빌링)를 쓴다 — 부르는 쪽이 빌링 설정을 config 로 넘긴다 (KIS 4번)
 *   · 빌키(bid)는 카드 대신 쓰는 결제용 번호다. 이 모듈은 로그를 남기지 않는다. 부르는 쪽도 화면·로그에 내보내지 않는다
 *   · 문서에 적힌 성공 코드(0000)만 성공으로 본다. 다른 승인 성공 코드(3001 등)가 오면 성공으로 단정하지 않고 결과 모름
 *   · 성공이어도 금액·거래번호·주문번호가 맞지 않으면 성공으로 돌려주지 않는다 (일반 결제와 같은 규칙)
 *
 * 이 파일은 DB·환경변수를 모른다.
 */

const { makeEncData, formatEdiDate } = require('./hash');
const { joinUrl, requestKis } = require('./client');
const {
  CODES, isBillingSuccess, isAnyApprovalSuccessCode, isCancelSuccess, isAlreadyCancelled
} = require('./codes');
const payment = require('./payment');

const {
  ORDER_NO_PATTERN, PHONE_PATTERN, EMAIL_PATTERN,
  byteLength, readText, toAmountText, toAmountNumber, assertConfig, failure
} = payment.internal;

const BILLING_PATHS = Object.freeze({
  PAY: '/v2/billing/payment',
  CANCEL: '/v2/billing/cancel',
  DELETE: '/v2/billing/delete',
  VALIDATE: '/v2/billing/validate'
});

// 빌키: 30바이트 이내 영문·숫자 (문서 예: billing00mcb412105311019441421). 이상한 값은 보내지도 받지도 않는다
const BID_PATTERN = /^[A-Za-z0-9_-]{1,30}$/;
// 할부 개월: 두 자리 00(일시불)·02~12
const QUOTA_PATTERN = /^(00|0[2-9]|1[0-2])$/;
// 거절(4xx) 본문에 이 코드가 있으면 처리됐는지 모름 — 자동결제 성공 코드는 일반 결제 성공 코드표에 없다
const BILLING_CONTRADICT = Object.freeze({ contradictCodes: [CODES.BILLING_SUCCESS] });

// [withContradict] - 시험용 옵션에 자동결제 성공 코드 판정을 더한다
function withContradict(options) {
  const base = options && typeof options === 'object' ? options : {};
  return { ...base, ...BILLING_CONTRADICT };
}

// [isValidBid] - 빌키 형식 검사
function isValidBid(value) {
  return typeof value === 'string' && BID_PATTERN.test(value);
}

// [nowOf] - 요청일시 기준 시각 (시험용 now 가 있으면 그 값)
function nowOf(now) {
  return now instanceof Date ? now : new Date();
}

// [buildBillingAuthRequest] - 카드 등록 결제창(KIS 인증)으로 보낼 form 값을 만든다 (순수 함수, 네트워크 없음)
// 파라미터: input.config(빌링 {mid, merchantKey, apiUrl}), input.order(일반 결제창과 같은 값 — buildAuthRequest 참고), input.now
//   · goodsAmt 는 필수지만 카드 등록 때는 돈이 빠지지 않는다 (빌링 4.1). 첫 결제 금액을 넣어 두면 결제창에 그 금액이 보인다
//   · 결제수단은 언제나 카드로 고정한다 (자동결제는 카드만)
// 반환값: {action, fields} / 예외: 입력이 잘못되면 Error (한글)
function buildBillingAuthRequest(input) {
  const src = input && typeof input === 'object' ? input : {};
  const order = src.order && typeof src.order === 'object' ? src.order : {};
  return payment.buildAuthRequest({ ...src, order: { ...order, payMethod: 'CARD' } });
}

// [issueBillingKey] - 카드 등록 결제창 인증 뒤 빌키 발급을 확정한다 (/v2/payment — 돈은 빠지지 않는다)
// 파라미터: input.config(빌링 설정), input.tid(인증 결과 거래번호), input.goodsAmt(결제창에 보낸 금액 — DB 값),
//           input.ordNo(선택, 우리 등록 번호 — 넘기면 응답과 대조), input.now / options.transport·options.timeoutMs (시험용)
// 반환값: Promise<{ok, uncertain, mayBeCharged, resultCd, resultMsg, tid, ordNo, bid, regDtm, fnNm, cardNo, appCardCd, cardType, error}>
//   ok=true 일 때만 bid 가 채워진다. 🔴 bid 는 로그·화면에 내보내지 말 것
//   mayBeCharged=true → 카드 승인 코드가 와서 돈이 빠졌을 수 있다: 부르는 쪽이 조회(inquire)로 확인
// 예외를 던지지 않는다
async function issueBillingKey(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  let settings;
  try {
    settings = assertConfig(src.config);
  } catch (err) {
    return failure(err.message, { mayBeCharged: false, bid: '' });
  }
  const tid = readText(src.tid);
  if (tid === '' || tid.length > 30) return failure('거래번호가 올바르지 않습니다.', { mayBeCharged: false, bid: '' });
  const goodsAmt = toAmountText(src.goodsAmt);
  if (!goodsAmt) return failure('금액이 올바르지 않습니다.', { mayBeCharged: false, bid: '' });
  const expectedOrdNo = readText(src.ordNo);

  const ediDate = formatEdiDate(nowOf(src.now));
  const body = {
    mid: settings.mid,
    tid,
    goodsAmt,
    ediDate,
    encData: makeEncData(settings.mid, ediDate, goodsAmt, settings.merchantKey),
    charset: 'UTF-8'
  };
  const response = await requestKis(joinUrl(settings.apiUrl, payment.PATHS.APPROVE), body, withContradict(options));
  if (!response.ok) {
    // 답을 못 받았으면 등록 대신 결제가 됐을 가능성도 지우지 않는다 (검수 M2)
    return {
      ok: false, uncertain: response.uncertain, mayBeCharged: response.uncertain, resultCd: '', resultMsg: '', tid, bid: '', error: response.error
    };
  }

  const data = response.data;
  const resultCd = readText(data.resultCd);
  const bid = readText(data.bid);
  const appNo = readText(data.appNo);
  const responseTid = readText(data.tid);
  const result = {
    ok: false,
    uncertain: false,
    mayBeCharged: false,
    resultCd,
    resultMsg: readText(data.resultMsg),
    tid: responseTid || tid,
    ordNo: readText(data.ordNo),
    bid: '',
    regDtm: readText(data.regDtm),
    fnNm: readText(data.fnNm),
    cardNo: readText(data.cardNo),
    appCardCd: readText(data.appCardCd),
    cardType: readText(data.cardType),
    error: null
  };

  // 정상 응답인데 결과코드가 없다 → 무엇이 처리됐는지 모른다 (검수 C2)
  if (resultCd === '') {
    result.uncertain = true;
    result.mayBeCharged = true;
    result.error = '카드 등록 응답에 결과코드가 없어 확인이 필요합니다.';
    return result;
  }
  if (!isBillingSuccess(resultCd)) {
    // 🔴 카드 승인 코드(3001 등)가 오면 등록이 아니라 결제가 됐을 수 있다 → 결과 모름 + 돈이 빠졌을 수 있음
    if (isAnyApprovalSuccessCode(resultCd)) {
      result.uncertain = true;
      result.mayBeCharged = true;
      result.error = `카드 등록 대신 승인 코드(${resultCd})가 왔습니다. 결제가 됐는지 확인이 필요합니다.`;
      return result;
    }
    result.error = result.resultMsg || `카드가 등록되지 않았습니다. (코드 ${resultCd || '없음'})`;
    return result;
  }
  // 🔴 성공 코드여도 승인번호가 있으면 등록과 함께 결제가 됐을 수 있다 (예제 코드의 옛 방식) → 첫 결제를 또 하지 않게 (검수 M1)
  //    6단계 실제 시험에서 카드 등록 응답 모양을 확인한 뒤 이 판정을 다시 본다
  if (appNo !== '') {
    result.uncertain = true;
    result.mayBeCharged = true;
    result.error = '카드 등록 응답에 승인번호가 있어 결제가 됐는지 확인이 필요합니다.';
    return result;
  }
  // 응답이 우리가 요청한 거래·등록의 것인지 확인 — 다르면 어느 카드가 등록됐는지 모른다
  if ((responseTid !== '' && responseTid !== tid) || (expectedOrdNo !== '' && result.ordNo !== '' && result.ordNo !== expectedOrdNo)) {
    result.uncertain = true;
    result.error = '카드 등록 응답의 거래번호·주문번호가 요청과 다릅니다.';
    return result;
  }
  if (!isValidBid(bid)) {
    // 성공이라는데 빌키가 없거나 이상하다 → 등록이 됐는지 모른다 (돈은 빠지지 않는 단계)
    result.uncertain = true;
    result.error = '카드 등록 결과에 빌키가 없어 확인이 필요합니다.';
    return result;
  }
  result.bid = bid;
  result.ok = true;
  return result;
}

// [billingPay] - 빌키로 결제한다 (/v2/billing/payment — 실제로 돈이 빠지는 단계)
// 파라미터: input.config(빌링 설정), input.bid, input.ordNo(이번 결제의 우리 주문번호 — 매번 다른 값), input.goodsNm,
//           input.goodsAmt(우리 DB 주문서 금액), input.ordNm, input.ordTel, input.quotaMon(선택, 기본 '00' 일시불),
//           선택: ordEmail, mbsUsrId, mbsIp, mbsReserved, goodsSplAmt·goodsVat·goodsSvsAmt, now
//           options.transport·options.timeoutMs (시험용)
// 반환값: Promise<{
//   ok, uncertain, amountMismatch, mayBeCharged, resultCd, resultMsg, payMethod, tid, appNo, appDtm, ordNo, amt,
//   fnNm, cardNo, cardType, quota, appCardCd, acqCardCd, cancelYN, error
// }>
//   amountMismatch=true → 승인은 났지만 금액이 다름: 부르는 쪽이 amt 로 즉시 취소(billingCancel)
//   uncertain=true      → 돈이 빠졌는지 모름: 부르는 쪽이 조회(inquire)로 확인. 🔴 같은 주문번호로 다시 결제하지 말 것
//   mayBeCharged=false  → KIS 가 실패 코드로 답했거나 요청이 닿지 않은 경우. 🔴 그래도 9999 같은 시스템 오류는
//                         실제로 승인됐을 수 있으니, 다음 회차 재시도 전에 이전 주문번호를 조회해 "결제 없음"일 때만 재시도할 것
// 예외를 던지지 않는다
async function billingPay(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  // 모든 결과에 mayBeCharged 를 붙인다 — "확정 실패(돈 안 빠짐)"만 false (검수 C1)
  const done = (r) => ({ ...r, mayBeCharged: Boolean(r.ok || r.amountMismatch || r.uncertain) });
  const blocked = (error) => done(failure(error, { amountMismatch: false }));
  let settings;
  try {
    settings = assertConfig(src.config);
  } catch (err) {
    return blocked(err.message);
  }
  const bid = readText(src.bid);
  if (!isValidBid(bid)) return blocked('빌키가 올바르지 않습니다.');
  const ordNo = readText(src.ordNo);
  if (!ORDER_NO_PATTERN.test(ordNo)) return blocked('주문번호는 영문·숫자·-·_ 로 40자 이내여야 합니다.');
  const goodsNm = readText(src.goodsNm);
  if (goodsNm === '' || byteLength(goodsNm) > 100) return blocked('상품명이 없거나 너무 깁니다. (최대 100바이트)');
  const goodsAmt = toAmountText(src.goodsAmt);
  if (!goodsAmt) return blocked('결제 금액이 올바르지 않습니다. (1원 이상 정수)');
  const ordNm = readText(src.ordNm);
  if (ordNm === '' || byteLength(ordNm) > 30) return blocked('구매자명이 없거나 너무 깁니다. (최대 30바이트)');
  const ordTel = readText(src.ordTel).replace(/[^0-9]/g, '');
  if (!PHONE_PATTERN.test(ordTel)) return blocked('구매자 전화번호 형식이 올바르지 않습니다.');
  // 숫자로 넘어온 할부(0·3)는 두 자리로 맞춘다. 비우면 일시불
  const quotaRaw = src.quotaMon === undefined || src.quotaMon === null || src.quotaMon === '' ? '00' : readText(src.quotaMon);
  const quotaMon = /^\d$/.test(quotaRaw) ? `0${quotaRaw}` : quotaRaw;
  if (!QUOTA_PATTERN.test(quotaMon)) return blocked('할부 개월 수가 올바르지 않습니다. (00 일시불, 02~12)');

  const ediDate = formatEdiDate(nowOf(src.now));
  const body = {
    bid,
    mid: settings.mid,
    ordNo,
    goodsNm,
    goodsAmt,
    quotaMon,
    ordNm,
    ordTel,
    currencyType: 'KRW',
    ediDate,
    encData: makeEncData(settings.mid, ediDate, goodsAmt, settings.merchantKey)
  };
  // 선택 항목 — 값이 있고 형식이 맞을 때만 넣는다 (선택 값이 이상하다고 결제를 막지는 않는다)
  const ordEmail = readText(src.ordEmail);
  if (ordEmail !== '' && byteLength(ordEmail) <= 60 && EMAIL_PATTERN.test(ordEmail)) body.ordEmail = ordEmail;
  for (const [key, maxBytes] of [['mbsUsrId', 20], ['mbsIp', 20], ['mbsReserved', 500]]) {
    const value = readText(src[key]);
    if (value !== '' && byteLength(value) <= maxBytes) body[key] = value;
  }
  for (const key of ['goodsSplAmt', 'goodsVat', 'goodsSvsAmt']) {
    if (src[key] === undefined || src[key] === null || src[key] === '') continue;
    const value = toAmountText(src[key], true);
    if (value === null) return blocked('공급가·부가세·봉사료는 0 이상의 정수여야 합니다.');
    body[key] = value;
  }

  const response = await requestKis(joinUrl(settings.apiUrl, BILLING_PATHS.PAY), body, withContradict(options));
  if (!response.ok) {
    return done({ ok: false, uncertain: response.uncertain, amountMismatch: false, resultCd: '', resultMsg: '', tid: '', error: response.error });
  }

  const data = response.data;
  const resultCd = readText(data.resultCd);
  const amt = toAmountNumber(data.amt);
  const result = {
    ok: false,
    uncertain: false,
    amountMismatch: false,
    resultCd,
    resultMsg: readText(data.resultMsg),
    payMethod: readText(data.payMethod).toUpperCase() || 'CARD',
    tid: readText(data.tid),
    appNo: readText(data.appNo),
    appDtm: readText(data.appDtm),
    ordNo: readText(data.ordNo),
    amt,
    fnNm: readText(data.fnNm),
    cardNo: readText(data.cardNo),
    cardType: readText(data.cardType),
    quota: readText(data.quota),
    appCardCd: readText(data.appCardCd),
    acqCardCd: readText(data.acqCardCd),
    cancelYN: readText(data.cancelYN),
    error: null
  };

  // 정상 응답인데 결과코드가 없다(칸 이름이 다른 경우 포함) → 결제됐는지 모른다. 자동 재시도로 두 번 결제하지 않게 (검수 C2)
  if (resultCd === '') {
    result.uncertain = true;
    result.error = '자동결제 응답에 결과코드가 없어 확인이 필요합니다.';
    return done(result);
  }
  if (!isBillingSuccess(resultCd)) {
    // 🔴 문서 성공 코드(0000)가 아닌 승인 성공 코드(3001 등) — 실제로는 결제됐을 수 있다 → 조회로 확인 (단정 금지)
    if (isAnyApprovalSuccessCode(resultCd)) {
      result.uncertain = true;
      result.error = `자동결제 응답 코드(${resultCd})가 문서와 달라 결제 여부 확인이 필요합니다.`;
      return done(result);
    }
    result.error = result.resultMsg || `결제가 승인되지 않았습니다. (코드 ${resultCd || '없음'})`;
    return done(result);
  }
  // 🔴 아래는 모두 "성공이라는데 앞뒤가 맞지 않는" 경우 — 돈은 빠졌을 수 있으므로 결과 모름으로 돌려준다
  if (result.tid === '') {
    result.uncertain = true;
    result.error = '자동결제 응답에 거래번호가 없어 확인이 필요합니다.';
    return done(result);
  }
  if (result.ordNo !== '' && result.ordNo !== ordNo) {
    result.uncertain = true;
    result.error = `자동결제 응답의 주문번호가 주문서와 다릅니다. (주문서 ${ordNo}, 응답 ${result.ordNo})`;
    return done(result);
  }
  if (result.cancelYN.toUpperCase() === 'Y') {
    result.uncertain = true;
    result.error = '자동결제 승인 응답이 취소 상태로 와서 확인이 필요합니다.';
    return done(result);
  }
  if (amt === null) {
    result.uncertain = true;
    result.error = '자동결제 응답에 승인 금액이 없어 확인이 필요합니다.';
    return done(result);
  }
  // 🔴 금액이 다르면 받지 않는다 — 부르는 쪽이 이 거래를 즉시 취소해야 한다
  if (amt !== Number(goodsAmt)) {
    result.amountMismatch = true;
    result.error = `승인 금액이 주문 금액과 다릅니다. (주문 ${goodsAmt}원, 승인 ${amt}원)`;
    return done(result);
  }
  result.ok = true;
  return done(result);
}

// [billingCancel] - 빌키로 결제한 거래를 취소한다 (/v2/billing/cancel)
// 파라미터: input.config(빌링 설정), input.tid, input.canAmt(취소금액), input.canMsg(취소사유, 필수),
//           선택: partCanFlg('0' 전체 기본 / '1' 부분), ordNo, canId, canNm, canIp, now
//           options.transport·options.timeoutMs (시험용)
// 반환값: Promise<{ok, uncertain, alreadyCancelled, resultCd, resultMsg, tid, amt, cancelYN, appDtm, error}>
//   빌링 가이드에 취소 성공 코드가 적혀 있지 않다 → KIS 결과코드 사이트의 취소 성공(2001·2211)만 성공,
//   0000 처럼 애매한 코드는 결과 모름 (부르는 쪽이 조회로 확인)
// 예외를 던지지 않는다
async function billingCancel(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  const blocked = (error) => failure(error, { alreadyCancelled: false });
  let settings;
  try {
    settings = assertConfig(src.config);
  } catch (err) {
    return blocked(err.message);
  }
  const tid = readText(src.tid);
  if (tid === '' || tid.length > 30) return blocked('거래번호가 올바르지 않습니다.');
  const canAmt = toAmountText(src.canAmt);
  if (!canAmt) return blocked('취소 금액이 올바르지 않습니다.');
  const canMsg = readText(src.canMsg);
  if (canMsg === '') return blocked('취소 사유가 없습니다.');
  const partCanFlg = readText(src.partCanFlg) || '0';
  if (!['0', '1'].includes(partCanFlg)) return blocked('부분취소 구분이 올바르지 않습니다.');

  const ediDate = formatEdiDate(nowOf(src.now));
  const body = {
    payMethod: 'CARD',             // 빌링 취소 규격·예제는 대문자 (일반 결제 취소는 소문자)
    tid,
    mid: settings.mid,
    canAmt,
    canMsg: payment.fitBytes(canMsg, 100),
    partCanFlg,
    ediDate,
    encData: makeEncData(settings.mid, ediDate, canAmt, settings.merchantKey)
  };
  const ordNo = readText(src.ordNo);
  if (ordNo !== '' && ORDER_NO_PATTERN.test(ordNo)) body.ordNo = ordNo;
  const canId = payment.fitBytes(readText(src.canId), 20);
  if (canId !== '') body.canId = canId;
  const canNm = payment.fitBytes(readText(src.canNm), 30);
  if (canNm !== '') body.canNm = canNm;
  const canIp = readText(src.canIp);
  if (canIp !== '' && byteLength(canIp) <= 20) body.canIp = canIp;

  const response = await requestKis(joinUrl(settings.apiUrl, BILLING_PATHS.CANCEL), body, withContradict(options));
  if (!response.ok) {
    return { ok: false, uncertain: response.uncertain, alreadyCancelled: false, resultCd: '', resultMsg: '', tid, error: response.error };
  }
  const data = response.data;
  const resultCd = readText(data.resultCd);
  const responseTid = readText(data.tid);
  const result = {
    ok: isCancelSuccess(resultCd),
    uncertain: false,
    alreadyCancelled: isAlreadyCancelled(resultCd),
    resultCd,
    resultMsg: readText(data.resultMsg),
    tid: responseTid || tid,
    amt: toAmountNumber(data.amt),
    cancelYN: readText(data.cancelYN),
    appDtm: readText(data.appDtm),
    error: null
  };
  if (!result.ok) {
    if (resultCd === '' || isBillingSuccess(resultCd)) {
      // 취소가 됐을 수도, 안 됐을 수도 있는 코드 → 결과 모름
      result.uncertain = true;
      result.error = `자동결제 취소 응답 코드(${resultCd})가 애매해 취소 여부 확인이 필요합니다.`;
      return result;
    }
    // "이미 취소됨"도 다른 거래의 응답이면 원래 거래 기준으로 닫을 수 없다 (재확인 경미)
    if (result.alreadyCancelled && responseTid !== '' && responseTid !== tid) {
      result.alreadyCancelled = false;
      result.uncertain = true;
      result.error = `취소 응답의 거래번호가 요청과 다릅니다. (요청 ${tid}, 응답 ${responseTid})`;
      return result;
    }
    result.error = result.resultMsg || `취소되지 않았습니다. (코드 ${resultCd || '없음'})`;
    return result;
  }
  // 취소 성공인데 다른 거래의 응답이면 원래 거래가 취소됐는지 모른다 (검수 M5)
  if (responseTid !== '' && responseTid !== tid) {
    result.ok = false;
    result.alreadyCancelled = false;
    result.uncertain = true;
    result.error = `취소 응답의 거래번호가 요청과 다릅니다. (요청 ${tid}, 응답 ${responseTid})`;
    return result;
  }
  // 전체 취소 성공인데 응답 금액이 요청과 다르면 얼마가 취소됐는지 모른다 → 결과 모름 (일반 취소와 같은 규칙)
  if (partCanFlg === '0' && result.amt !== null && result.amt !== Number(canAmt)) {
    result.ok = false;
    result.uncertain = true;
    result.error = `취소 응답 금액이 요청과 다릅니다. (요청 ${canAmt}원, 응답 ${result.amt}원)`;
  }
  return result;
}

// [bidRequest] - 빌키만 보내는 요청(삭제·유효 확인)의 공통 부분
// 반환값: Promise<{blocked?: object, response?: object}>
async function bidRequest(src, path, options) {
  let settings;
  try {
    settings = assertConfig(src.config);
  } catch (err) {
    return { blocked: err.message };
  }
  const bid = readText(src.bid);
  if (!isValidBid(bid)) return { blocked: '빌키가 올바르지 않습니다.' };
  const ediDate = formatEdiDate(nowOf(src.now));
  const body = {
    mid: settings.mid,
    bid,
    ediDate,
    encData: makeEncData(settings.mid, ediDate, bid, settings.merchantKey)
  };
  return { response: await requestKis(joinUrl(settings.apiUrl, path), body, withContradict(options)) };
}

// [deleteBillingKey] - 빌키를 KIS 에서 지운다 (자동결제 해지·카드 변경) — 🔴 한 번 지우면 되살릴 수 없다 (빌링 3.5.1)
// 파라미터: input.config(빌링 설정), input.bid, input.now / options (시험용)
// 반환값: Promise<{ok, uncertain, resultCd, resultMsg, error}>
//   uncertain=true → 지워졌는지 모름(실패 코드 포함): 부르는 쪽이 나중에 다시 지우기를 시도한다 (그동안 이 빌키로 결제하지 않는다)
//   ok=false + uncertain=false 는 요청 전에 막힌 경우(설정·빌키 형식)뿐
// 예외를 던지지 않는다
async function deleteBillingKey(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  const { blocked, response } = await bidRequest(src, BILLING_PATHS.DELETE, options);
  if (blocked) return failure(blocked);
  if (!response.ok) return { ok: false, uncertain: response.uncertain, resultCd: '', resultMsg: '', error: response.error };
  const resultCd = readText(response.data.resultCd);
  const resultMsg = readText(response.data.resultMsg);
  if (isBillingSuccess(resultCd)) return { ok: true, uncertain: false, resultCd, resultMsg, error: null };
  // 실패 코드도 "이미 지워진 빌키"일 수 있다(앞선 삭제가 시간 초과였던 경우) → 단정하지 않고 결과 모름 (검수 M4)
  //   "이미 삭제됨" 코드는 6단계 실제 시험에서 확인해 따로 구분한다. 그때까지 부르는 쪽은 이 빌키로 결제하지 말고 다시 지우기를 시도
  return { ok: false, uncertain: true, resultCd, resultMsg, error: resultMsg || `카드 등록 삭제 결과를 확인하지 못했습니다. (코드 ${resultCd || '없음'})` };
}

// [validateBillingKey] - 빌키가 아직 쓸 수 있는지 확인한다 (/v2/billing/validate — 돈은 빠지지 않는다)
// 파라미터: input.config(빌링 설정), input.bid, input.now / options (시험용)
// 반환값: Promise<{ok, valid, uncertain, resultCd, resultMsg, cardNm, cardCd, error}>
//   valid=true 는 0000 일 때만. 그 밖에는 모두 uncertain=true (확정 "사용 불가" 코드는 6단계에서 확인 후 추가)
// 예외를 던지지 않는다
async function validateBillingKey(input, options) {
  const src = input && typeof input === 'object' ? input : {};
  const { blocked, response } = await bidRequest(src, BILLING_PATHS.VALIDATE, options);
  if (blocked) return failure(blocked, { valid: false, cardNm: '', cardCd: '' });
  if (!response.ok) {
    return { ok: false, valid: false, uncertain: response.uncertain, resultCd: '', resultMsg: '', cardNm: '', cardCd: '', error: response.error };
  }
  const data = response.data;
  const resultCd = readText(data.resultCd);
  const result = {
    ok: isBillingSuccess(resultCd),
    valid: isBillingSuccess(resultCd),
    uncertain: false,
    resultCd,
    resultMsg: readText(data.resultMsg),
    cardNm: readText(data.cardNm),
    cardCd: readText(data.cardCd),
    error: null
  };
  if (!result.ok) {
    // "쓸 수 없음" 확정 코드는 6단계 실제 시험에서 확인한다. 그때까지는 일시 장애와 구분할 수 없어 결과 모름 (검수 M3)
    //   🔴 부르는 쪽은 valid=false 만 보고 카드 등록을 지우지 말 것 (되살릴 수 없다)
    result.uncertain = true;
    result.error = result.resultMsg || `등록된 카드 상태를 확인하지 못했습니다. (코드 ${resultCd || '없음'})`;
  }
  return result;
}

module.exports = {
  BILLING_PATHS,
  buildBillingAuthRequest,
  issueBillingKey,
  billingPay,
  billingCancel,
  deleteBillingKey,
  validateBillingKey
};
