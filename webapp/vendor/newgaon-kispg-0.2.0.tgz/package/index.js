/**
 * [KISPG 공용 결제 모듈 — 공개 진입점]
 * 파일: backend/lib/kispg/index.js
 *
 * 학원관리(LMS)·근태관리 두 프로그램이 같은 코드로 KIS정보통신(KISPG)과 결제를 주고받기 위한 모듈이다.
 *   · DB, 화면, 환경변수를 전혀 모른다 → 상점ID·상점키·KIS 주소는 부르는 쪽이 넘긴다
 *   · 외부 라이브러리 없음 (Node 18 기본 crypto·fetch)
 *   · 일반 결제(결제창 인증 → 승인 · 취소 · 조회) + 자동결제(빌링 — 카드 등록 · 빌키 결제 · 취소 · 삭제 · 유효 확인)
 *     자동결제는 별도 상점ID·상점키(빌링)를 config 로 넘긴다
 *
 * 사용 예 (학원관리 연결부에서):
 *   const kispg = require('../lib/kispg');
 *   const config = { mid: process.env.KISPG_MID, merchantKey: process.env.KISPG_MERCHANT_KEY,
 *                    apiUrl: process.env.KISPG_API_URL };   // 🔴 없으면 결제하지 않는다
 *   const form = kispg.buildAuthRequest({ config, order: { ordNo, goodsNm, goodsAmt, ordNm, ordTel, returnUrl, payMethod: 'CARD' } });
 *   // → 화면이 form.action 으로 form.fields 를 POST (KIS 결제창)
 *   const auth = kispg.parseAuthResult(req.body);          // returnUrl 로 돌아온 인증 결과
 *   const paid = await kispg.approve({ config, tid: auth.tid, goodsAmt: 주문서금액, ordNo: 주문서주문번호 });
 *   // paid.ok / paid.uncertain(결과 모름 → inquire 로 확인) / paid.amountMismatch(→ paid.amt 로 cancel)
 */

const { version: VERSION } = require('./package.json');
const hash = require('./hash');
const codes = require('./codes');
const client = require('./client');
const payment = require('./payment');
const billing = require('./billing');

module.exports = {
  VERSION,

  // KIS 주소
  LIVE_API_URL: payment.LIVE_API_URL,
  TEST_API_URL: payment.TEST_API_URL,
  PATHS: payment.PATHS,
  PAY_METHODS: payment.PAY_METHODS,

  // 일반 결제
  buildAuthRequest: payment.buildAuthRequest,
  parseAuthResult: payment.parseAuthResult,
  verifyAuthResult: payment.verifyAuthResult,
  parseNotification: payment.parseNotification,
  verifyNotification: payment.verifyNotification,
  approve: payment.approve,
  cancel: payment.cancel,
  inquire: payment.inquire,

  // 자동결제(빌링) — 🔴 빌키(bid)는 로그·화면에 내보내지 않는다
  BILLING_PATHS: billing.BILLING_PATHS,
  buildBillingAuthRequest: billing.buildBillingAuthRequest,
  issueBillingKey: billing.issueBillingKey,
  billingPay: billing.billingPay,
  billingCancel: billing.billingCancel,
  deleteBillingKey: billing.deleteBillingKey,
  validateBillingKey: billing.validateBillingKey,

  // 결과코드
  CODES: codes.CODES,
  isApprovalSuccess: codes.isApprovalSuccess,
  isAnyApprovalSuccessCode: codes.isAnyApprovalSuccessCode,
  isCancelSuccess: codes.isCancelSuccess,
  isVacntReleaseSuccess: codes.isVacntReleaseSuccess,
  isVacntAlreadyDeposited: codes.isVacntAlreadyDeposited,
  isVacntDepositNotiCode: codes.isVacntDepositNotiCode,
  isBillingSuccess: codes.isBillingSuccess,
  isAlreadyCancelled: codes.isAlreadyCancelled,
  isNotFoundCode: codes.isNotFoundCode,

  // 도우미
  makeEncData: hash.makeEncData,
  formatEdiDate: hash.formatEdiDate,
  fitBytes: payment.fitBytes,
  isAllowedApiUrl: client.isAllowedApiUrl,
  DEFAULT_TIMEOUT_MS: client.DEFAULT_TIMEOUT_MS
};
