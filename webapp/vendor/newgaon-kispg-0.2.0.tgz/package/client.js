/**
 * [KISPG 공용 모듈 — KIS 서버와 주고받기]
 * 파일: backend/lib/kispg/client.js
 *
 * 승인·취소·조회는 서버끼리 JSON 으로 주고받는다 (연동가이드 3.2~3.4: POST, UTF-8, application/json).
 *
 * 🔴 지켜야 할 것
 *   · KIS 주소(apiUrl)는 부르는 쪽이 반드시 넘긴다. 없으면 요청하지 않는다 (설정 안 된 PC 에서 실제 결제가 나가는 사고 방지)
 *   · https 만 허용 (내 컴퓨터 시험 주소만 예외) — 암호값·거래번호가 오가므로
 *   · "결과 모름"(uncertain) 구분: 요청이 KIS 에 닿았는지 모르는 실패(시간 초과·응답 도중 끊김·이상한 응답)는
 *     돈이 빠졌을 수 있다. 부르는 쪽이 조회(inquire)나 취소(cancel)로 정리해야 한다.
 *
 * 이 파일은 DB·환경변수를 모른다. Node 18 기본 fetch 만 쓴다 (외부 라이브러리 없음).
 */

const { isAnyApprovalSuccessCode, isCancelSuccess, isVacntReleaseSuccess } = require('./codes');

// KIS 응답을 기다리는 최대 총 시간 (밀리초). 승인은 카드사까지 다녀오므로 넉넉히 둔다
const DEFAULT_TIMEOUT_MS = 30000;

// 시험·개발용으로 http 를 허용하는 내 컴퓨터 주소 (URL.hostname 기준 — IPv6 는 대괄호 포함)
const LOOPBACK_HOSTS = Object.freeze(['127.0.0.1', 'localhost', '[::1]']);

// 요청이 KIS 에 "확실히 닿지 않은" 오류 — 주소 찾기 실패·연결 거부·인증서 문제(본문을 보내기 전에 끊김)
const NOT_SENT_ERROR_CODES = Object.freeze([
  'ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'ENETUNREACH', 'EHOSTUNREACH', 'ERR_INVALID_URL',
  'CERT_HAS_EXPIRED', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'DEPTH_ZERO_SELF_SIGNED_CERT',
  'SELF_SIGNED_CERT_IN_CHAIN', 'ERR_TLS_CERT_ALTNAME_INVALID'
]);

// [isAllowedApiUrl] - 암호값을 실어 보내도 되는 KIS 주소인가 (https, 또는 내 컴퓨터의 http)
// 파라미터: url(string)
// 반환값: boolean - 형식이 이상하면 false (보내지 않는 쪽이 안전)
function isAllowedApiUrl(url) {
  try {
    const target = new URL(url);
    if (target.protocol === 'https:') return true;
    return target.protocol === 'http:' && LOOPBACK_HOSTS.includes(target.hostname);
  } catch (_) {
    return false;
  }
}

// [joinUrl] - KIS 기본 주소 + 경로 (끝의 / 중복 제거)
// 파라미터: baseUrl(string) - 예: https://testapi.kispg.co.kr, path(string) - 예: /v2/payment
// 반환값: string
function joinUrl(baseUrl, path) {
  return `${String(baseUrl).replace(/\/+$/, '')}${path}`;
}

// [errorCodeOf] - 오류 객체에서 원인 코드를 꺼낸다 (fetch 는 cause 안에 넣어 준다)
// 파라미터: err(any)
// 반환값: string - 없으면 ''
function errorCodeOf(err) {
  if (!err) return '';
  if (typeof err.code === 'string') return err.code;
  if (err.cause && typeof err.cause.code === 'string') return err.cause.code;
  return '';
}

// [isNotSentError] - 요청이 KIS 에 닿지 않은 것이 확실한 오류인가
// 파라미터: err(any)
// 반환값: boolean - 모르면 false ("결과 모름"으로 다루는 쪽이 안전)
function isNotSentError(err) {
  return NOT_SENT_ERROR_CODES.includes(errorCodeOf(err));
}

// [postJson] - JSON 을 POST 하고 응답 본문을 문자열로 돌려준다 (기본 전송기)
// 파라미터: url(string), body(object), timeoutMs(number) - 총 대기 시간 (응답 본문을 다 받을 때까지)
// 반환값: Promise<{status: number, text: string}>
// 예외: 네트워크 오류·시간 초과 시 Error 를 던진다 (시간 초과는 code='ETIMEDOUT')
async function postJson(url, body, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8', Accept: 'application/json' },
      body: JSON.stringify(body),
      // 🔴 다른 주소로 넘겨도 따라가지 않는다 — 따라가면 https 검사를 건너뛰고 거래 전문을 엉뚱한 곳에 다시 보낸다 (검수 M3)
      redirect: 'manual',
      signal: controller.signal
    });
    const text = await res.text();
    return { status: res.status, text };
  } catch (err) {
    if (controller.signal.aborted) {
      const timeoutErr = new Error(`KIS 응답 시간 초과 (${Math.round(timeoutMs / 100) / 10}초)`);
      timeoutErr.code = 'ETIMEDOUT';
      throw timeoutErr;
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// [requestKis] - KIS 에 요청을 보내고 JSON 응답을 읽는다. 예외를 던지지 않는다
// 파라미터: url(string), body(object), options.transport(function, 선택) - (url, body, timeoutMs) → {status, text}. 시험용 가짜 전송기
//           options.timeoutMs(number, 선택)
//           options.contradictCodes(string[], 선택) - 거절(4xx) 본문에 있으면 "처리됐는지 모름"으로 볼 성공 코드를 더한다
//                                                    (자동결제 성공 코드 0000 처럼 일반 결제 성공 코드표에 없는 것)
// 반환값: Promise<{ok: true, data: object} | {ok: false, uncertain: boolean, error: string}>
//   ok=true 는 "KIS 가 JSON 으로 답했다"는 뜻일 뿐 결제 성공이 아니다 (성공 판정은 payment.js)
async function requestKis(url, body, rawOptions) {
  const options = rawOptions && typeof rawOptions === 'object' ? rawOptions : {};
  const transport = typeof options.transport === 'function' ? options.transport : postJson;
  const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : DEFAULT_TIMEOUT_MS;

  let response;
  try {
    response = await transport(url, body, timeoutMs);
  } catch (err) {
    const message = err && err.message ? err.message : 'KIS 통신 오류';
    return { ok: false, uncertain: !isNotSentError(err), error: `KIS 통신 실패: ${message}` };
  }

  const status = response && Number(response.status);
  const text = response && typeof response.text === 'string' ? response.text : '';
  // KIS 쪽 서버 오류 — 처리 도중 문제가 났을 수 있어 결과를 알 수 없다
  if (!status || status >= 500) {
    return { ok: false, uncertain: true, error: `KIS 서버 오류 (HTTP ${status || '응답 없음'})` };
  }
  // 다른 주소로 넘기라는 응답(3xx) — 따라가지 않았으므로 KIS 가 처리했는지 모른다
  if (status >= 300 && status < 400) {
    return { ok: false, uncertain: true, error: `KIS 가 다른 주소로 넘기라고 응답했습니다 (HTTP ${status})` };
  }
  let data = null;
  try {
    data = JSON.parse(text);
  } catch (_) {
    data = null;
  }
  const isObject = Boolean(data) && typeof data === 'object' && !Array.isArray(data);
  // 4xx 는 KIS 가 요청을 거절한 것(처리 안 됨) → 결과가 확정된 실패. 본문에 성공 코드가 있어도 믿지 않는다 (검수 L3)
  if (status >= 400) {
    const message = isObject && typeof data.resultMsg === 'string' && data.resultMsg.trim() ? ` — ${data.resultMsg.trim()}` : '';
    // 거절 응답인데 본문에 승인·취소 성공 코드가 있으면 앞뒤가 안 맞는다 → 처리됐는지 모름 (재검수 L-a)
    const bodyCode = isObject && typeof data.resultCd === 'string' ? data.resultCd.trim() : '';
    const extraCodes = Array.isArray(options.contradictCodes) ? options.contradictCodes : [];
    const contradicts = isAnyApprovalSuccessCode(bodyCode) || isCancelSuccess(bodyCode) || isVacntReleaseSuccess(bodyCode)
      || (bodyCode !== '' && extraCodes.includes(bodyCode));
    return { ok: false, uncertain: contradicts, error: `KIS 가 요청을 거절했습니다 (HTTP ${status})${message}` };
  }
  // 2xx 인데 못 읽으면 처리됐는지 모른다
  if (!isObject) {
    return { ok: false, uncertain: true, error: `KIS 응답을 읽을 수 없습니다 (HTTP ${status})` };
  }
  return { ok: true, data };
}

module.exports = {
  DEFAULT_TIMEOUT_MS,
  isAllowedApiUrl,
  joinUrl,
  isNotSentError,
  postJson,
  requestKis
};
