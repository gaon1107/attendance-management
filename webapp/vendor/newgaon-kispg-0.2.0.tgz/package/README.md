# @newgaon/kispg — KISPG(KIS정보통신) 결제 공용 모듈

학원관리(newgaon-LMS)와 근태관리가 **같은 코드**로 KISPG와 결제를 주고받기 위한 모듈입니다.
DB·화면·환경변수를 전혀 모릅니다. 상점ID·상점키·KIS 주소는 부르는 쪽이 넘깁니다.

- 규격 근거: KISPG 가맹점 연동가이드 v1.1.14, 빌링 가이드 v1.0.10 (`kis결제/` 폴더 — git 제외), 결과코드 조회 사이트 https://www.kispg.co.kr/result_code (2026-10-17 조회)
- 계획서: 루트 `KISPG_결제연동_수정계획서_20261017.md`(일반 결제), `KISPG_자동결제_수정계획서_20261020.md`(자동결제)
- 원본 위치: `newgaon-LMS/backend/lib/kispg/` ← **여기가 유일한 원본**
- 근태관리 이식: 학원관리에서 실제 결제 확인·운영 배포를 마친 뒤 (문자 모듈 `moashot`과 같은 순서, `npm pack` 으로 묶어 설치)

## 무엇을 하는가 / 하지 않는가

| 모듈이 하는 것 | 프로그램(연결부)이 하는 것 |
|---|---|
| 암호값(encData) 만들기 — SHA-256(mid + 요청일시 + 금액 + 상점키) | 상점ID·상점키를 `.env` 에서 꺼내기 |
| 결제창 form 값 만들기 (`buildAuthRequest`) | 금액 계산(요금표) · 주문서 저장 (DB) |
| 결제창 결과 읽기·암호값 검사 (`parseAuthResult`, `verifyAuthResult`) | 주문번호로 주문서 찾기 · 금액 대조 |
| 승인·취소·조회 요청 (`approve`, `cancel`, `inquire`) | 승인되면 이용 기간 연장 · 결제내역 저장 |
| 성공 코드 판정, "결과 모름"(uncertain) 구분, 금액 불일치 감지 | 결과 모름·금액 불일치 때 조회·취소로 정리 |
| 한국 시간 요청일시 | 화면 · 권한 · 로그 |

## 사용법

```js
const kispg = require('./lib/kispg');
const config = {
  mid: process.env.KISPG_MID,
  merchantKey: process.env.KISPG_MERCHANT_KEY,   // 🔴 브라우저로 보내지 않는다 — 모듈도 결과에 넣지 않음
  apiUrl: process.env.KISPG_API_URL               // kispg.TEST_API_URL 또는 kispg.LIVE_API_URL. 🔴 없으면 결제하지 않음
};

// ① 결제창으로 보낼 값 (서버에서 만들어 화면에 준다)
const { action, fields } = kispg.buildAuthRequest({
  config,
  order: { ordNo: 'LMS-...', goodsNm: '스마트출결 1개월', goodsAmt: 5500, ordNm: '홍길동', ordTel: '01012345678',
           returnUrl: 'https://lms.newgaon.com/api/subscription-pay/return', payMethod: 'CARD' }
});
// 화면: <form method="post" action={action} target="iframe 이름"> + fields 를 hidden 으로 → submit
//   KIS 창은 끝나면 감싼 화면에 postMessage({resultCode, data}) 로 결과를 건넨다 → 화면이 data 를 returnUrl 로 form POST
//   (_self 로 화면 전체를 넘기면 결과를 받을 곳이 없어 KIS 빈 화면에서 멈춤 — 2026-10-25 실결제 시험, src/pages/account/PaymentPage.jsx submitToKis)

// ② returnUrl 로 돌아온 인증 결과
const auth = kispg.parseAuthResult(req.body);    // auth.ok = 0000 + 거래번호. 아직 돈이 빠진 것 아님

// ③ 승인 (돈이 빠지는 단계) — 금액·주문번호는 반드시 우리 DB 주문서 값
const paid = await kispg.approve({ config, tid: auth.tid, goodsAmt: order.amount, ordNo: order.orderNo });
if (paid.ok) { /* 이용 기간 연장 */ }
else if (paid.amountMismatch) { /* 즉시 kispg.cancel — canAmt 는 paid.amt(실제 승인 금액). null 이면 먼저 inquire 로 금액 확인 */ }
else if (paid.uncertain) { /* kispg.inquire 로 돈이 빠졌는지 확인 → 빠졌으면 처리 또는 취소. 실패로 단정 금지 */ }

// ④ 취소 / ⑤ 조회
await kispg.cancel({ config, tid, payMethod: 'CARD', canAmt: 5500, canMsg: '처리 오류로 자동 취소' });
await kispg.inquire({ config, tid, goodsAmt: 5500 });  // status: approved / cancelled / waiting / not_found / unknown
```

`approve`·`cancel`·`inquire` 는 **예외를 던지지 않습니다.** 모든 문제는 `{ ok: false, error }` 로 돌아옵니다.
`buildAuthRequest` 는 입력이 잘못되면 한글 메시지로 예외를 던집니다(부르는 쪽이 잡아서 안내).

## 자동결제(빌링) — `billing.js` (0.2.0)

> 🔴 자동결제는 **별도 상점ID·상점키(빌링)** 를 씁니다(KIS 회신 4번). `config` 에 빌링 설정을 넘기세요. 일반 결제 키로 보내면 암호값 오류가 납니다.
> 🔴 빌키(`bid`)는 카드 대신 쓰는 결제용 번호입니다. 모듈은 로그를 남기지 않습니다. 부르는 쪽도 화면·로그·응답에 내보내지 마세요.

```js
const billingConfig = { mid: process.env.KISPG_BILLING_MID, merchantKey: process.env.KISPG_BILLING_MERCHANT_KEY, apiUrl: process.env.KISPG_API_URL };

// ① 카드 등록 결제창 (결제수단은 언제나 카드. goodsAmt 는 필수지만 돈은 빠지지 않음)
const form = kispg.buildBillingAuthRequest({ config: billingConfig, order: { ordNo: 'LMSB-…', goodsNm, goodsAmt, ordNm, ordTel, returnUrl } });
// ② returnUrl 로 온 인증 결과(parseAuthResult) → 카드 등록 확정 (/v2/payment, 응답에 빌키)
const reg = await kispg.issueBillingKey({ config: billingConfig, tid: auth.tid, goodsAmt: 등록때금액, ordNo: 'LMSB-…' });
// reg.ok → reg.bid 저장 / reg.uncertain → 등록 여부 모름 / reg.mayBeCharged → 결제됐을 수 있음: 조회(inquire)로 확인 후 첫 결제
// ③ 빌키 결제 (매번 다른 주문번호. 같은 주문번호로 재시도 금지)
const paid = await kispg.billingPay({ config: billingConfig, bid, ordNo: 'LMS-…', goodsNm, goodsAmt: 주문서금액, ordNm, ordTel });
// paid.ok / paid.uncertain(→ inquire 로 확인, config 는 빌링) / paid.amountMismatch(→ billingCancel 로 paid.amt 취소)
// 🔴 paid.mayBeCharged === false (확정 실패, 돈 안 빠짐)일 때만 "실패 → 다음 날 재시도"로 처리한다
// ④ 취소 · ⑤ 삭제(되살릴 수 없음) · ⑥ 유효 확인
await kispg.billingCancel({ config: billingConfig, tid, canAmt, canMsg });
await kispg.deleteBillingKey({ config: billingConfig, bid });
await kispg.validateBillingKey({ config: billingConfig, bid });
```

| 판정 | 기준 |
|---|---|
| 카드 등록·빌키 결제 성공 | `0000` (빌링 가이드). 다른 승인 성공 코드(3001 등)·결과코드 없음은 **결과 모름**. 카드 등록 응답에 승인번호가 있으면 결과 모름 + `mayBeCharged` |
| 빌키 삭제·유효 확인 | `0000` 만 성공. 그 밖의 코드는 **결과 모름**(이미 지워진 빌키·일시 장애와 구분 못 함). 🔴 `valid=false` 만 보고 카드 등록을 지우지 말 것 |
| 빌키 결제 취소 성공 | `2001`·`2211` (결과코드 사이트). `0000` 은 애매해 **결과 모름**, `2004`·`2013` 은 이미 취소됨 |
| 빌키 결제 "성공인데 결과 모름" | 거래번호 없음 · 주문번호 다름 · 취소 표시(cancelYN=Y) · 금액 없음 |
| 빌키 결제 `mayBeCharged` | 성공 · 금액 불일치 · 결과 모름이면 true. **확정 실패만 false** |
| 빌키 결제 취소 "성공인데 결과 모름" | 응답 거래번호가 요청과 다름 · 전체 취소인데 응답 금액이 다름 |
| 거절(4xx) 응답 | 본문에 성공 코드(`0000`·3001·4000·2001·2211)가 있으면 결과 모름, 아니면 확정 실패 |

**6단계 실제 시험에서 확인할 것**: 빌키가 `/v2/payment` 응답으로 오는지(예제 코드는 returnUrl 에서 바로 받는 옛 방식) · 카드 등록 응답에 승인번호·금액이 오는지 · 실제 성공 코드 · "이미 삭제된 빌키"·"쓸 수 없는 카드" 코드(확정 목록으로 추가) · 빌키 결제·취소에 charset 이 필요한지(지금은 안 보냄 — 한글 깨짐 확인) · 자동결제 승인의 조회 모양(trxStatus·cancelYN).

## 결과코드 (KIS 결과코드 조회 사이트 기준)

| 코드 | 뜻 | 쓰는 곳 |
|---|---|---|
| 0000 | 정상처리 | 결제창 인증 성공 |
| 3001 | 카드 결제 성공 | 카드 승인 (간편결제 포함 — 5단계 시험에서 확인) |
| 4000 | 계좌이체 결제 성공 | 계좌이체 승인 |
| 2001 / 2211 | 취소 성공 / 환불 성공 | 취소 |
| 2004 / 2013 | 이미 취소된 거래 / 취소 완료 거래 | 취소 — 다시 취소할 필요 없음(`alreadyCancelled`) |

성공이 아닌 코드는 KIS 메시지를 그대로 `error` 로 돌려줍니다(KIS: 실패 코드는 예고 없이 추가·삭제될 수 있음).

## 🔴 함정

1. **상점키는 서버에만.** 결제창 값에는 암호값(encData)만 들어갑니다.
2. **요청일시(ediDate)는 10분 안에만 유효.** 서버 시계가 틀리면 KIS가 거절합니다. 모듈이 한국 시간으로 만듭니다.
3. **"결과 모름"(uncertain).** 시간 초과·응답 도중 끊김·KIS 5xx·이상한 응답이면 돈이 빠졌을 수 있습니다. 실패로 단정하지 말고 `inquire` 로 확인하세요.
4. **승인 금액 대조.** 성공 코드여도 금액이 주문서와 다르면 `amountMismatch` → 즉시 취소하세요.
5. **브라우저를 거쳐 온 값은 믿지 않습니다.** returnUrl 로 오는 인증 결과(`ordNo`·`amt`·`mbsReserved`)는 원장님 브라우저를 거치므로 바뀔 수 있습니다. 학원 구분·금액은 **DB 주문서**에서 꺼내고, 거래번호(tid)는 주문 하나에만 쓰이도록 연결부가 막습니다(DB 유일 조건).
6. **조회(`inquire`)에서 "돈이 안 빠졌다"고 볼 수 있는 것은 `status === 'not_found'` 하나뿐입니다.** KIS가 미승인으로 확인한 코드(OR01 결제 미완료·OR02 주문 없음·6505)일 때만 나옵니다. 조회를 못 한 경우(설정 오류·연결 거부·거절)를 포함해 그 밖에는 모두 `uncertain` 입니다. "승인"인데 금액이 없거나 거래번호·주문번호가 다를 때도 `uncertain` 입니다.
   - 취소 응답 금액의 뜻(취소 금액인지 남은 금액인지)은 아직 확인 전입니다. 그래서 전체 취소 성공이 `uncertain` 으로 나올 수 있습니다. 연결부는 취소 재시도 횟수에 상한을 두고, 2004·2013(`alreadyCancelled`)이 오면 취소가 끝난 것으로 봅니다. 응답 금액의 뜻은 5단계 실제 시험에서 확인합니다.
7. **다른 주소로 넘기는 응답(3xx)은 따라가지 않습니다.** 결과 모름으로 돌려줍니다.
8. **시험 결제도 실제 승인입니다.** KIS 문서: 시험용 상점ID 결제는 당일 23:30 자동 취소. 사장님 확인 없이 KIS 서버로 시험하지 않습니다(평소 시험은 가짜 전송기).

## 문서와 다른 점 / KIS 확인 결과 (2026-10-17 문의 → 10-19 회신)

- **응답 암호값 검사식**: KIS 회신으로 확정 — 인증 결과(returnUrl)는 `mid + 응답의 ediDate + goodsAmt + 상점키`. 승인 응답(/v2/payment)에는 암호값이 없습니다. 실제 시험 결제에서 일치를 확인하기 전까지는 결제 차단의 단독 근거로 쓰지 않습니다(`verifyAuthResult`).
- **조회 미승인 코드**: KIS 회신으로 OR01(결제 미완료)·OR02(주문 정보 없음)는 미승인 확정.
- **빌링 9.1 예시 암호값**(`af462d6b…`)은 문서의 식으로 계산해도 나오지 않습니다. 같은 식인 9.2·9.3 예시는 일치하므로 문서 오기로 보고 시험 기준에서 뺐습니다.
- **취소 암호값**: 일반 가이드 7.2는 `canAmt`, 빌링 9.4는 `goodsAmt`로 적혀 있지만, KIS 회신으로 둘 다 취소 금액(`canAmt`)으로 확정.
- **결제수단 표기**: 결제창은 대문자(CARD/BANK), 취소는 소문자(card/bank)로 문서에 적힌 대로 보냅니다.

## 시험

```bash
cd backend && npx jest tests/kispg.test.js tests/kispgBilling.test.js
```
인터넷·상점 계정 없이 돌아갑니다. 암호값은 KIS 문서 예시값과 대조합니다.

## 변경 이력
- 0.2.0 (2026-10-20) 자동결제(빌링): 카드 등록 결제창·등록 확정·빌키 결제·취소·삭제·유효 확인, `isBillingSuccess`, 통신의 거절 응답 판정에 `contradictCodes` 선택 항목(기존 동작 그대로)
  - 검수(code-reviewer) 반영: 빌키 결제 `mayBeCharged`(확정 실패만 false, C1), 결과코드 없는 정상 응답은 결과 모름(C2), 카드 등록 응답의 승인번호·통신 결과 모름은 결제 가능성 표시(M1·M2), 삭제·유효 확인의 실패 코드는 결과 모름(M3·M4), 취소 응답 거래번호 대조(M5), 숫자 할부 두 자리로
- 0.1.1 (2026-10-20) 조회 OR01(결제 미완료)을 미승인(`not_found`)으로 — KIS 10-19 회신. 이전에는 결과 모름으로 남아 주문이 정리되지 않았음
- 0.1.0 (2026-10-17) 1차: 일반 결제(결제창 값·인증 결과·승인·취소·조회), 결과코드, 한국 시간 요청일시
  - 검수(code-reviewer) 반영: 조회 오류를 "없음"으로 단정하지 않음(C1), 성공 코드+수단 불일치는 결과 모름(C2), 응답 거래번호·주문번호 대조(M2), 리다이렉트 안 따라감(M3), 4xx 확정 실패, 조회 금액 불일치 표시
  - 재검수 반영: 조회는 not_found 외 전부 uncertain, 승인인데 금액 없음·주문번호 불일치도 uncertain, 4xx 본문의 성공 코드는 uncertain
