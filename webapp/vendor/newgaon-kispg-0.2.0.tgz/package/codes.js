/**
 * [KISPG 공용 모듈 — 결과코드]
 * 파일: backend/lib/kispg/codes.js
 *
 * 출처: KISPG 결과코드 조회 사이트 https://www.kispg.co.kr/result_code (2026-10-17 조회)
 *   · 공통 0000 "정상처리" — 결제창 인증 성공으로 쓴다
 *   · 신용카드 3001 "카드 결제 성공" (간편결제도 카드 결제창을 거치므로 같은 코드로 본다 — 5단계 시험에서 확인)
 *   · 계좌이체 4000 "계좌이체 결제 성공"
 *   · 취소/환불 2001 "취소 성공", 2211 "환불 성공"
 *   · 가상계좌 4100 "발급 성공", 4110 "입금 성공", 4200 "해제(입금 전 취소) 성공", 3109 "이미 입금처리 완료되어 취소 불가"
 *     (2026-10-30 KIS 회신·결과코드 사이트 — 가상계좌_결제_수정계획서_2026-10-29.md 2-0)
 *   · 빌링(자동결제) 문서는 "0000 : 성공" 으로 적혀 있다 → isBillingSuccess (billing.js)
 *
 * ⚠️ KIS 는 "성공 코드 외의 코드는 예고 없이 추가·삭제될 수 있다"고 안내한다.
 *    그래서 실패는 코드표로 판정하지 않고 "성공 코드가 아니면 실패"로만 본다. 메시지는 KIS 응답 문구를 그대로 쓴다.
 */

const CODES = Object.freeze({
  AUTH_SUCCESS: '0000',      // 결제창 인증 성공
  CARD_SUCCESS: '3001',      // 카드 승인 성공
  BANK_SUCCESS: '4000',      // 계좌이체 승인 성공
  CANCEL_SUCCESS: '2001',    // 취소 성공
  REFUND_SUCCESS: '2211',    // 환불 성공 (가상계좌 환불 등)
  VACNT_ISSUED: '4100',      // 가상계좌 발급 성공 — 아직 돈이 들어온 것이 아니다 (입금 대기)
  VACNT_DEPOSITED: '4110',   // 가상계좌 입금 성공
  VACNT_RELEASED: '4200',    // 가상계좌 해제(입금 전 발급 취소) 성공
  VACNT_ALREADY_DEPOSITED: '3109', // 이미 입금되어 발급 취소 불가
  BILLING_SUCCESS: '0000'    // 빌링 문서 기준 성공 (자동결제 — billing.js)
});

// 결제수단별 승인 성공 코드 (결제수단은 대문자로 맞춰서 찾는다)
//   가상계좌(VACNT)의 "승인 성공"은 계좌 발급 성공(4100) — 돈은 입금 알림 때 들어온다
const APPROVAL_SUCCESS_BY_METHOD = Object.freeze({
  CARD: CODES.CARD_SUCCESS,
  BANK: CODES.BANK_SUCCESS,
  VACNT: CODES.VACNT_ISSUED
});

// 이미 취소된 거래로 보는 코드 — 다시 취소할 필요가 없다는 뜻 (2004 이미 취소된 거래, 2013 취소 완료 거래)
const ALREADY_CANCELLED_CODES = Object.freeze(['2004', '2013']);

// 조회에서 "승인되지 않은 결제"가 확실한 코드
//   OR01 결제 미완료, OR02 주문 정보 없음 — KIS 회신(2026-10-19 메일 8번): 둘 다 "미승인"
//   6505 결제요청 내역이 존재하지 않습니다 (KIS 결과코드 사이트)
// 🔴 이 목록에 없는 오류(9999 시스템 오류·암호값 오류 등)는 "없음"이 아니라 "결과 모름"으로 본다 (검수 C1)
//    — 오류를 "없음"으로 단정하면, 실제로 돈이 빠진 거래를 실패 처리하게 된다
const NOT_FOUND_CODES = Object.freeze(['OR01', 'OR02', '6505']);

// 가상계좌 입금 알림(결제통보)에서 "입금 성공"으로 보는 코드
//   결제통보 문서는 0000, 운영 첫 실입금 알림(2026-10-30)은 4110 으로 왔다 → 둘 다 받는다
//   어느 쪽이든 반영 직전에 KIS 조회로 다시 확인하므로 알림 코드만으로 돈이 반영되지는 않는다
const VACNT_DEPOSIT_NOTI_CODES = Object.freeze([CODES.AUTH_SUCCESS, CODES.VACNT_DEPOSITED]);

// [isVacntDepositNotiCode] - 입금 알림의 결과코드가 입금 성공(0000·4110)인가
// 파라미터: resultCd(string)
// 반환값: boolean
function isVacntDepositNotiCode(resultCd) {
  return VACNT_DEPOSIT_NOTI_CODES.includes(resultCd);
}

// [isAnyApprovalSuccessCode] - 결제수단과 상관없이 승인 성공 코드(3001·4000·4100) 중 하나인가
// 파라미터: resultCd(string)
// 반환값: boolean - 수단 이름이 예상과 달라도 돈이 빠졌을 수 있는지 가려낼 때 쓴다
function isAnyApprovalSuccessCode(resultCd) {
  return Object.values(APPROVAL_SUCCESS_BY_METHOD).includes(resultCd);
}

// [isNotFoundCode] - 조회 응답이 "결제 없음(미승인)"이 확실한 코드인가 (OR01·OR02·6505)
// 파라미터: resultCd(string)
// 반환값: boolean
function isNotFoundCode(resultCd) {
  return NOT_FOUND_CODES.includes(resultCd);
}

// [isApprovalSuccess] - 승인 응답이 성공인가
// 파라미터: payMethod(string) - CARD/BANK (대소문자 무관), resultCd(string)
// 반환값: boolean - 결제수단과 맞는 성공 코드일 때만 true (계좌이체인데 3001 이면 false)
function isApprovalSuccess(payMethod, resultCd) {
  const method = typeof payMethod === 'string' ? payMethod.trim().toUpperCase() : '';
  // 바깥 값이 키가 되는 조회 — 자기 칸에 있는 수단만 본다 (toString 같은 이름 방지)
  const expected = Object.prototype.hasOwnProperty.call(APPROVAL_SUCCESS_BY_METHOD, method)
    ? APPROVAL_SUCCESS_BY_METHOD[method]
    : undefined;
  return Boolean(expected) && resultCd === expected;
}

// [isCancelSuccess] - 취소 응답이 성공인가 (취소 성공 또는 환불 성공)
// 파라미터: resultCd(string)
// 반환값: boolean
function isCancelSuccess(resultCd) {
  return resultCd === CODES.CANCEL_SUCCESS || resultCd === CODES.REFUND_SUCCESS;
}

// [isVacntReleaseSuccess] - 가상계좌 발급 취소(입금 전 해제) 응답이 성공(4200)인가
// 파라미터: resultCd(string)
// 반환값: boolean - 카드·계좌이체 취소에는 쓰지 않는다 (payment.cancel 이 가상계좌일 때만 본다)
function isVacntReleaseSuccess(resultCd) {
  return resultCd === CODES.VACNT_RELEASED;
}

// [isVacntAlreadyDeposited] - "이미 입금되어 발급 취소 불가"(3109) 응답인가
// 파라미터: resultCd(string)
// 반환값: boolean
function isVacntAlreadyDeposited(resultCd) {
  return resultCd === CODES.VACNT_ALREADY_DEPOSITED;
}

// [isBillingSuccess] - 자동결제(빌키 발급·결제·삭제·유효 확인) 응답이 성공인가 (빌링 가이드 4.4·5.4·6.4: "0000 : 성공")
// 파라미터: resultCd(string)
// 반환값: boolean
function isBillingSuccess(resultCd) {
  return resultCd === CODES.BILLING_SUCCESS;
}

// [isAlreadyCancelled] - "이미 취소된 거래" 응답인가
// 파라미터: resultCd(string)
// 반환값: boolean
function isAlreadyCancelled(resultCd) {
  return ALREADY_CANCELLED_CODES.includes(resultCd);
}

module.exports = {
  CODES,
  APPROVAL_SUCCESS_BY_METHOD,
  ALREADY_CANCELLED_CODES,
  NOT_FOUND_CODES,
  VACNT_DEPOSIT_NOTI_CODES,
  isApprovalSuccess,
  isVacntDepositNotiCode,
  isAnyApprovalSuccessCode,
  isCancelSuccess,
  isVacntReleaseSuccess,
  isVacntAlreadyDeposited,
  isBillingSuccess,
  isAlreadyCancelled,
  isNotFoundCode
};
