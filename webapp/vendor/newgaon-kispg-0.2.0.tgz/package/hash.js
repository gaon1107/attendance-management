/**
 * [KISPG 공용 모듈 — 암호값·요청일시]
 * 파일: backend/lib/kispg/hash.js
 *
 * 규격 출처: KISPG 가맹점 연동가이드 v1.1.14 7장, 빌링 가이드 v1.0.10 9장
 *   encData = Hex(SHA-256)( mid + ediDate + 값 + 상점키 )
 *     · 값 = 결제·승인·조회는 금액(goodsAmt), 취소는 취소금액(canAmt), 빌키 삭제는 빌키(bid)
 *   ediDate = 전문 요청일시 yyyymmddhhmmss — KIS 는 "현재 시각 -10분까지 유효"
 *
 * 이 파일은 DB·환경변수를 모른다.
 */

const crypto = require('crypto');

// 한국 시간 = UTC + 9시간 (서머타임 없음)
const KST_OFFSET_MS = 9 * 60 * 60 * 1000;

// [makeEncData] - KIS 위변조 방지 암호값을 만든다
// 파라미터: mid(string) - 상점ID, ediDate(string) - 요청일시 14자리,
//           value(string|number) - 금액 또는 빌키, merchantKey(string) - 상점키 (🔴 브라우저로 보내지 말 것)
// 반환값: string - 64자리 소문자 16진수
function makeEncData(mid, ediDate, value, merchantKey) {
  const source = `${mid}${ediDate}${value}${merchantKey}`;
  return crypto.createHash('sha256').update(source, 'utf8').digest('hex');
}

// [formatEdiDate] - 요청일시를 한국 시간 yyyymmddhhmmss 로 만든다
// 파라미터: date(Date, 선택) - 기본은 지금. 서버 시계가 UTC 여도 한국 시간으로 계산한다
// 반환값: string - 예: '20261017153045'
function formatEdiDate(date = new Date()) {
  const kst = new Date(date.getTime() + KST_OFFSET_MS);
  const pad = (n) => String(n).padStart(2, '0');
  return `${kst.getUTCFullYear()}${pad(kst.getUTCMonth() + 1)}${pad(kst.getUTCDate())}`
    + `${pad(kst.getUTCHours())}${pad(kst.getUTCMinutes())}${pad(kst.getUTCSeconds())}`;
}

// [safeEqualHex] - 두 암호값이 같은지 비교한다 (길이가 같으면 걸리는 시간이 같은 비교)
// 파라미터: a(string), b(string)
// 반환값: boolean - 둘 중 하나라도 비었거나 다르면 false
function safeEqualHex(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a === '' || b === '') return false;
  const left = Buffer.from(a.toLowerCase(), 'utf8');
  const right = Buffer.from(b.toLowerCase(), 'utf8');
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

module.exports = {
  makeEncData,
  formatEdiDate,
  safeEqualHex
};
