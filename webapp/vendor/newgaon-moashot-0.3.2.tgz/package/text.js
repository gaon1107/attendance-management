/**
 * [비즈모아샷 공용 모듈 — 글자 처리]
 * 파일: backend/lib/moashot/text.js
 *
 * 비즈모아샷은 EUC-KR 기반 시스템이다. 그래서
 *   · 단문/장문 구분은 "EUC-KR 바이트 수"로 한다 (한글 2바이트, 영문·숫자 1바이트)
 *   · 이모지처럼 EUC-KR 이 모르는 글자는 보내면 깨진다 → 보내기 전에 찾아내야 한다
 * 이 파일은 DB·화면·환경변수를 전혀 모른다. 근태관리 등 다른 프로그램도 그대로 쓴다.
 */

const iconv = require('iconv-lite');

// 단문(SMS) 최대 바이트. 이 값을 넘으면 장문(LMS)으로 보낸다. (상세매뉴얼: 단문 90byte)
const MAX_SHORT_BYTES = 90;
// 장문(LMS) 최대 바이트. 이 값을 넘으면 접수 자체를 거부한다. (상세매뉴얼: 장문 2,000byte)
const MAX_LONG_BYTES = 2000;

// [getEuckrByteLength] - 문자열을 EUC-KR 로 바꿨을 때의 바이트 수
// 파라미터: text(string) - 본문
// 반환값: number - 바이트 수 (빈 값·null 은 0)
function getEuckrByteLength(text) {
  if (text === null || text === undefined) return 0;
  return iconv.encode(String(text), 'euc-kr').length;
}

// [isShortMessage] - 단문(90바이트 이하)인지 판정
// 파라미터: text(string) - 본문
// 반환값: boolean - true 면 단문(sendType=3), false 면 장문(sendType=5)
function isShortMessage(text) {
  return getEuckrByteLength(text) <= MAX_SHORT_BYTES;
}

// [findUnsupportedChars] - EUC-KR 로 표현할 수 없는 글자를 찾아낸다 (화면 입력 차단용)
// 파라미터: text(string) - 검사할 본문
// 반환값: string[] - 표현 불가 글자 목록 (중복 제거, 등장 순서). 없으면 빈 배열
// 동작 원리: iconv-lite 는 EUC-KR 로 못 바꾸는 글자를 물음표('?', 0x3F) 한 바이트로 바꿔 놓는다.
//           그래서 글자 하나씩 바꿔 보고, 결과가 '?' 인데 원래 글자가 '?' 가 아니면 표현 불가로 본다.
// @example
// findUnsupportedChars('등원했어요 😊')  // ['😊']
// findUnsupportedChars('정상 문자?')      // []   ← 진짜 물음표는 정상
function findUnsupportedChars(text) {
  if (text === null || text === undefined || text === '') return [];
  const found = [];
  const seen = new Set();
  // for...of 는 이모지 같은 2단위(서로게이트 쌍) 글자도 한 글자로 돌려준다
  for (const ch of String(text)) {
    if (seen.has(ch)) continue;
    const encoded = iconv.encode(ch, 'euc-kr');
    const isReplaced = encoded.length === 1 && encoded[0] === 0x3F && ch !== '?';
    if (isReplaced) {
      seen.add(ch);
      found.push(ch);
    }
  }
  return found;
}

// [stripPhone] - 전화번호에서 숫자만 남긴다 ("010-1234-5678" → "01012345678")
// 파라미터: phone(string) - 전화번호
// 반환값: string - 숫자만 남은 문자열 (null 은 빈 문자열)
function stripPhone(phone) {
  if (phone === null || phone === undefined) return '';
  return String(phone).replace(/[^0-9]/g, '');
}

// [isValidPhone] - 수신 가능한 전화번호 형태인지 (숫자만, 9~12자리)
// 파라미터: phone(string) - 숫자만 남긴 전화번호
// 반환값: boolean
function isValidPhone(phone) {
  return /^[0-9]{9,12}$/.test(phone || '');
}

// [isValidSenderPhone] - 발신번호로 쓸 수 있는 형태인지 (숫자만, 8~12자리)
// 파라미터: phone(string) - 숫자만 남긴 전화번호
// 반환값: boolean
// 수신번호와 따로 두는 이유: 학원이 1588-1234 같은 8자리 대표번호를 발신번호로 등록해 쓰는 경우가 있다.
function isValidSenderPhone(phone) {
  return /^[0-9]{8,12}$/.test(phone || '');
}

// [maskPhone] - 로그용 전화번호 가리기 ("01012345678" → "010****5678")
// 파라미터: phone(string) - 숫자만 남긴 전화번호
// 반환값: string
function maskPhone(phone) {
  const digits = stripPhone(phone);
  if (digits.length < 7) return '****';
  return `${digits.slice(0, 3)}****${digits.slice(-4)}`;
}

module.exports = {
  MAX_SHORT_BYTES,
  MAX_LONG_BYTES,
  getEuckrByteLength,
  isShortMessage,
  findUnsupportedChars,
  stripPhone,
  isValidPhone,
  isValidSenderPhone,
  maskPhone
};
