# @newgaon/moashot — 비즈모아샷 문자/알림톡 공용 모듈

학원관리(newgaon-LMS)와 근태관리가 **같은 코드**로 비즈모아샷에 문자를 보내기 위한 모듈입니다.
DB·화면·환경변수를 전혀 모릅니다. 계정과 발송 주소는 부르는 쪽이 넘깁니다.

- 규격 근거: `비즈모아샷_연동_인수인계_2026-09-01.md` (3장 API 규격, 3-5 함정 8가지)
- 원본 위치: `newgaon-LMS/backend/lib/moashot/` ← **여기가 유일한 원본**
- 근태관리에는 `npm pack` 으로 만든 `newgaon-moashot-<버전>.tgz` 를 설치한다 (아래 참고)

## 무엇을 하는가 / 하지 않는가

| 모듈이 하는 것 | 프로그램이 하는 것 |
|---|---|
| 파라미터 조립 (`commType=0` + `pwd`·https 전용, `utfSave=1`, `nSubject=1`, POST 고정) | 계정 꺼내오기 (DB) · 복호화 |
| 단문/장문 자동 구분 (EUC-KR 90byte) | 발송 이력 저장 (`indexCode` 포함) |
| `SUCCESS:` 응답 판정 | 결과 콜백 주소(returnUrl) 열기 |
| 콜백 `data` 다건 파싱 · 항목명 소문자 정규화 | 이력 상태 갱신 |
| 결과코드 → 한글 사유 | 요금 단가 · 화면 |
| EUC-KR 표현 불가 글자 찾기 (`findUnsupportedChars`) | 입력 화면에서 그 글자를 막기 |

## 사용법

```js
const moashot = require('./lib/moashot');

// 문자 접수
const r = await moashot.sendSms(
  {
    account: { id: '아이디', password: '비밀번호평문', sender: '02-123-4567' },
    to: '010-1234-5678',                 // 여러 명이면 배열 (내용이 같을 때만)
    text: '[알림] 홍길동 학생이 등원하였습니다.',
    title: '등원 알림',                   // 장문일 때만 제목으로 붙음
    returnUrl: 'https://lms.example.com/api/sms/callback/토큰',  // 없으면 결과 콜백 안 받음
  },
  { sendUrl: process.env.MOASHOT_SEND_URL || '' }   // 🔴 주소가 없거나 빈 값이면 발송하지 않고 실패 반환
);
// r.ok        : 접수 성공 여부 (★ 전송 성공이 아님 — 결과는 콜백으로 온다)
// r.indexCode : 접수ID → 이력에 저장해 두어야 콜백 결과를 붙일 수 있다
// r.error     : 실패 사유 (한글)
```

**발송 주소는 반드시 명시한다.** 모듈은 `sendUrl` 이 없으면 절대 발송하지 않는다. 운영 `.env` 에
`MOASHOT_SEND_URL=https://biz.moashot.com/EXT/URLASP/mssendUTF.asp` (= `moashot.DEFAULT_SEND_URL`) 를 넣고,
테스트 안전장치(`tests/setup/safety.js`)에서는 빈 값으로 덮어쓴다.

**비밀 취급.** `buildSmsParams` 가 만든 `params.pwd` 는 비밀번호 그대로다 (0.3.0 부터 — 예전 `commCode`(MD5) 방식은 운영에서 결과코드 21 "패스워드 오류"). `sendSms`·`sendKakao` 는 https 주소로만 보낸다 (알림톡도 `pwd` 평문 — 0.3.1 부터). `postForm`·`postRaw` 를 직접 부르면 이 확인을 건너뛰므로 쓰지 말 것.
로그에 남길 일이 있으면 `moashot.redactParams(params)` 를 거친다.

```js

// 결과 콜백 해석 (express: req.body)
const parsed = moashot.parseCallback(req.body);
// parsed.results → [{ indexCode, code, ok, reason }, ...]   ← 여러 건이 한 번에 올 수 있다
// parsed.reSend  → 알림톡 실패로 문자 대체발송이 됐으면 true

// 화면 입력 차단
moashot.findUnsupportedChars('등원했어요 😊');   // ['😊']
```

## 접수와 전송은 다르다

| 단계 | 시점 | 판정 |
|---|---|---|
| 1 · 접수 | `sendSms` 응답 즉시 | `ok === true` |
| 2 · 전송결과 | 잠시 후 returnUrl 로 POST | `parseCallback(...).results[i].ok` |

접수 성공 후 이력 상태는 `pending` 으로 두고, 콜백에서 `sent`/`failed` 로 확정하는 것을 권장한다.

## 근태관리에 설치하기

```bash
cd newgaon-LMS/backend/lib/moashot
npm pack                       # → newgaon-moashot-0.3.1.tgz
```
만든 tgz 를 근태관리 `webapp/vendor/` 에 두고 `package.json` 에 `"@newgaon/moashot": "file:vendor/newgaon-moashot-0.3.1.tgz"` 로 설치한다.
**두 프로그램의 버전이 같은지** 이 README 의 버전 이력으로 확인한다.

## 테스트

```bash
cd newgaon-LMS/backend
npx jest tests/moashot.test.js
```
계정 없이 돌아간다 (네트워크를 쓰지 않는다).

## 버전 이력

| 버전 | 날짜 | 내용 |
|---|---|---|
| 0.1.0 | 2026-09-02 | 문자 발송·콜백 해석·결과코드·글자 판정 (1-A) |
| 0.2.0 | 2026-09-02 | 알림톡(kakao.js): 템플릿 변수 치환·payload 조립(WL 버튼만, re_send 대체문자)·접수·응답 해석. sms.js 에 postRaw 분리 |
| 0.3.0 | 2026-10-02 | 문자 비밀번호를 매뉴얼 기본 방식 `commType=0` + `pwd` 로 변경(MD5 방식은 운영 첫 실발송이 결과코드 21). `sendSms` 는 https 주소만(내 컴퓨터 http 예외), 아니면 발송 거부 |
| 0.3.1 | 2026-10-03 | `sendKakao` 도 https 주소만(내 컴퓨터 http 예외). 아니면 요청 전에 멈추고 `notSent:true` (호출처가 문자로 대체해도 이중 발송 아님) |
| 0.3.2 | 2026-10-30 | `postRaw`(문자·알림톡 공용): 주소 조회(DNS) 실패(`getaddrinfo`)일 때만 1초 뒤 1회 다시 보냄 — 요청이 나가기 전이라 중복 발송 없음, 총 대기 시간 안에서만(남은 시간 2초 미만이면 안 함). 다시 보낸 요청이 연결 전 시간 초과면 처음 DNS 오류를 그대로 던짐(알림톡 `notSent` 유지). 운영에서 DNS 1회 무응답으로 등하원 문자 1통 실패 |

## 실물 검증 전 미확정 사항 (계정 확보 후 확인)

- `utfSave=1` 로 이모지를 보냈을 때 수신 폰에서 어떻게 보이는지
- 콜백 시간 항목 이름 (`send_start` / `Send_start`) — 소문자 정규화로 우회했으므로 동작에는 영향 없음
- `nSubject=1` 장문 제목 (매뉴얼에 없고 회신에만 근거)
- `똠`·`뷁` 같은 확장 완성형(CP949) 글자 — iconv-lite 의 euc-kr 은 CP949 표라 통과시키는데, 비즈모아샷이 순수 KS X 1001 이면 깨진다. 실물 검증 3번 항목에 추가할 것

## 화면(입력 차단) 쪽에서 알아둘 것

- `findUnsupportedChars` 는 보이지 않는 글자도 돌려준다: `❤️` → `['❤', '️']`, 가족 이모지의 결합자(`‍`), 웹에서 복사한 문장의 NBSP(` `).
  화면에서는 NBSP 를 일반 공백으로 바꾼 뒤 검사하고, 안내 문구에는 보이는 글자만 보여주는 처리가 필요하다 (4단계).
- 근태관리(TypeScript)에서 쓰려면 `index.d.ts` 타입 선언이 필요하다 (6단계에서 추가).
