/**
 * [비즈모아샷 공용 모듈 — 문자(SMS/LMS) 발송]
 * 파일: backend/lib/moashot/sms.js
 *
 * 규격 출처: 비즈모아샷 URL 연동 상세매뉴얼 + 2026-09-01 회신 (인수인계 문서 3-1 절)
 *   POST https://biz.moashot.com/EXT/URLASP/mssendUTF.asp  (UTF-8, form-urlencoded)
 *   응답 본문이 "SUCCESS:" 로 시작하면 접수 성공 (returnType=3)
 *
 * 🔴 지켜야 할 것
 *   · GET 금지 → 항상 POST (값에 & 가 있으면 GET 은 전송 안 됨)
 *   · utfSave=1 항상 → 이모지가 있어도 500 으로 접수 실패하지 않는다 (깨질 뿐)
 *   · 비밀번호는 매뉴얼 기본 방식 commType=0 + pwd(비밀번호 그대로). 발송 주소는 https 만 허용한다(sendSms 에서 막음).
 *     (2026-10-02 변경) 예전에는 commType=1 + commCode=MD5(비밀번호) 를 썼으나 운영 첫 실발송이 전부 결과코드 21
 *     "패스워드 오류" 였다. commType=1 은 전체 매뉴얼 p.10 에만 있고 MD5 값의 표기 형식이 적혀 있지 않으며,
 *     간편 매뉴얼·전체 매뉴얼의 호출 예시(p.9)는 모두 pwd 그대로 + "HTTPS 호출 권장" 이다. 알림톡도 이 방식만 받는다.
 *     ⚠️ params 에 비밀번호가 그대로 있다. 로그·응답·화면에 그대로 찍지 말 것. 로그가 필요하면 redactParams() 를 거칠 것.
 *   · 장문 제목은 nSubject=1 + title (매뉴얼에 없는 비공개 파라미터, 회신으로 확인)
 *   · 접수 성공 ≠ 전송 성공. 실제 전송 결과는 returnUrl 콜백으로 온다 (callback.js)
 *   · 발송 주소(sendUrl)는 부르는 쪽이 반드시 넘긴다. 안 넘기면 발송하지 않는다.
 *     (환경변수 미설정 상태의 개발 PC·테스트에서 실제 서버로 나가는 사고 방지)
 *
 * 이 파일은 DB·환경변수를 모른다. 계정과 발송 주소는 부르는 쪽이 넘겨준다.
 */

const https = require('https');
const http = require('http');
const crypto = require('crypto');
const iconv = require('iconv-lite');
const {
  MAX_LONG_BYTES,
  getEuckrByteLength,
  isShortMessage,
  stripPhone,
  isValidPhone,
  isValidSenderPhone
} = require('./text');

// 비즈모아샷 실제 발송 주소 (UTF-8 판). 부르는 쪽이 options.sendUrl 로 "명시적으로" 넘겨야 쓰인다.
const DEFAULT_SEND_URL = 'https://biz.moashot.com/EXT/URLASP/mssendUTF.asp';
// 비즈모아샷 응답을 기다리는 최대 총 시간 (밀리초). 무응답이든 찔끔찔끔 오든 이 시간이 지나면 끊는다.
const DEFAULT_TIMEOUT_MS = 10000;
// 예약 발송 시각 형식: YYYYMMDDHHmmss 14자리 (매뉴얼 본문의 16자리는 오기, 예시 14자리가 맞음)
const RESERVE_AT_PATTERN = /^\d{14}$/;
// 접수ID(indexCode) 에 허용하는 글자 (콤마 구분 목록에 들어가므로 콤마·공백 금지)
const INDEX_CODE_PATTERN = /^[A-Za-z0-9_-]{1,40}$/;

// [getMd5Hex] - MD5 해시 (예전 commType=1 비밀번호 전송용 — 2026-10-02 부터 문자 발송에는 쓰지 않음, 공개 함수라 남겨 둠)
// 파라미터: value(string)
// 반환값: string - 32자리 소문자 16진수
function getMd5Hex(value) {
  return crypto.createHash('md5').update(String(value)).digest('hex');
}

// [generateIndexCode] - 우리 쪽 접수ID 를 만든다 (결과 콜백을 이력에 붙일 때 쓰는 열쇠)
// 반환값: string - 예: "M20260902123045123-a1b2c3d4" (시각 + 난수, 최대 40자)
function generateIndexCode() {
  const now = new Date();
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`
    + `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}${pad(now.getMilliseconds(), 3)}`;
  return `M${stamp}-${crypto.randomBytes(4).toString('hex')}`;
}

// [readOptionalString] - 선택 문자열 항목을 읽는다. 없으면 '', 문자열이 아니면 예외
// 파라미터: value(any), label(string) - 오류 메시지에 쓸 항목 이름
// 반환값: string
function readOptionalString(value, label) {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') throw new Error(`${label} 은(는) 문자열이어야 합니다.`);
  return value;
}

// [buildSmsParams] - 발송 요청 파라미터를 조립한다 (순수 함수, 네트워크 없음)
// 파라미터: input(object)
//   account.id(string)       - 비즈모아샷 아이디
//   account.password(string) - 비밀번호 평문 (pwd 로 그대로 보낸다 — https 전용, 2026-10-02 부터 MD5 안 씀)
//   account.sender(string)   - 발신번호 (비즈모아샷에 사전 등록된 번호, 8~12자리)
//   to(string|string[])      - 수신번호. 여러 명이면 배열 (내용이 같을 때만). 중복 번호는 하나로 합친다
//   text(string)             - 본문
//   title(string, 선택)      - 제목. 장문일 때만 의미 있음 (nSubject=1)
//   indexCode(string|string[], 선택) - 접수ID. 없으면 자동 생성. 수신자 수와 같아야 함
//   returnUrl(string, 선택)  - 결과 콜백 주소(http/https). 있으면 nType=3, 없으면 nType=4(안 받음)
//   reserveAt(string, 선택)  - 예약 시각 YYYYMMDDHHmmss (7일 이내)
//   subId(string, 선택)      - 우리 쪽 발송자 구분값
// 반환값: {params: object, meta: {indexCodes: string[], isShort: boolean, byteLength: number, recipients: string[]}}
// 예외: 입력이 잘못되면 Error 를 던진다 (한글 메시지). 부르는 쪽이 잡아서 결과로 바꾼다.
function buildSmsParams(input) {
  const { account, reserveAt } = input || {};
  const text = input && input.text !== null && input.text !== undefined ? String(input.text) : '';

  // 1. 계정 검증
  if (!account || !account.id || !account.password || !account.sender) {
    throw new Error('문자 발송 계정(아이디·비밀번호·발신번호)이 설정되지 않았습니다.');
  }
  const sender = stripPhone(account.sender);
  if (!isValidSenderPhone(sender)) {
    throw new Error('발신번호 형식이 올바르지 않습니다.');
  }

  // 2. 수신번호 검증 (문자열 하나 또는 배열). 같은 번호가 두 번 있으면 결과코드 34(번호중복)로 실패하므로 하나로 합친다
  const rawList = Array.isArray(input.to) ? input.to : [input.to];
  const rawIndexCodes = input.indexCode === undefined || input.indexCode === null || input.indexCode === ''
    ? null
    : (Array.isArray(input.indexCode) ? input.indexCode : [input.indexCode]).map((c) => String(c));
  if (rawIndexCodes && rawIndexCodes.length !== rawList.length) {
    throw new Error('접수ID 개수가 수신번호 개수와 다릅니다.');
  }
  const recipients = [];
  const givenIndexCodes = [];
  const seen = new Set();
  rawList.forEach((raw, i) => {
    const phone = stripPhone(raw);
    if (!isValidPhone(phone)) throw new Error('수신 전화번호가 올바르지 않습니다.');
    if (seen.has(phone)) return; // 중복 번호는 처음 것만 (접수ID 도 처음 것을 따라간다)
    seen.add(phone);
    recipients.push(phone);
    if (rawIndexCodes) givenIndexCodes.push(rawIndexCodes[i]);
  });
  if (recipients.length === 0) {
    throw new Error('수신 전화번호가 올바르지 않습니다.');
  }

  // 3. 본문 검증
  if (text.trim() === '') {
    throw new Error('보낼 내용이 없습니다.');
  }
  const byteLength = getEuckrByteLength(text);
  if (byteLength > MAX_LONG_BYTES) {
    throw new Error(`본문이 너무 깁니다. (EUC-KR 기준 ${byteLength}바이트, 최대 ${MAX_LONG_BYTES}바이트)`);
  }
  const isShort = isShortMessage(text);

  // 4. 접수ID: 수신자마다 하나씩. 없으면 자동 생성
  const indexCodes = rawIndexCodes ? givenIndexCodes : recipients.map(() => generateIndexCode());
  if (indexCodes.some((c) => !INDEX_CODE_PATTERN.test(c))) {
    throw new Error('접수ID 는 영문·숫자·-·_ 로 40자 이내여야 합니다.');
  }

  // 5. 선택 항목 검증
  if (reserveAt !== undefined && reserveAt !== null && reserveAt !== '' && !RESERVE_AT_PATTERN.test(String(reserveAt))) {
    throw new Error('예약 시각은 YYYYMMDDHHmmss 14자리여야 합니다.');
  }
  const title = readOptionalString(input.title, '제목').trim();
  const subId = readOptionalString(input.subId, '발송자 구분값').trim();
  const returnUrl = readOptionalString(input.returnUrl, '결과 콜백 주소').trim();
  if (returnUrl !== '' && !/^https?:\/\/\S+$/i.test(returnUrl)) {
    throw new Error('결과 콜백 주소는 http 또는 https 로 시작하는 주소여야 합니다.');
  }

  // 6. 파라미터 조립 (모든 값은 문자열)
  const params = {
    uid: String(account.id),
    pwd: String(account.password),       // 매뉴얼 기본 방식: 비밀번호 그대로 (https 로만 보낸다 — sendSms 에서 확인)
    commType: '0',                       // 0 = 일반(commCode 사용 안 함). 예전 1(MD5) 은 운영에서 패스워드 오류(21)
    sendType: isShort ? '3' : '5',       // 3 단문 / 5 장문
    toNumber: recipients.join(','),
    fromNumber: sender,
    contents: text,
    indexCode: indexCodes.join(','),
    returnType: '3',                     // 3 = "SUCCESS:indexCode" 본문으로 응답
    nType: returnUrl ? '3' : '4',        // 3 접수+전송결과 콜백 / 4 콜백 안 받음
    utfSave: '1'                         // 🔴 항상 1 (EUC-KR 미지원 글자가 있어도 접수 실패 방지)
  };
  // 제목은 장문일 때만 붙인다. nSubject=1 이어야 실제 문자 제목이 된다 (회신으로 확인된 비공개 파라미터)
  if (!isShort && title !== '') {
    params.title = title;
    params.nSubject = '1';
  }
  if (returnUrl !== '') params.returnUrl = returnUrl;
  if (reserveAt) params.startTime = String(reserveAt);
  if (subId !== '') params.subId = subId;

  return { params, meta: { indexCodes, isShort, byteLength, recipients } };
}

// [redactParams] - 로그용으로 비밀값을 가린 복사본을 만든다 (pwd·commCode 는 비밀번호와 같은 급)
// 파라미터: params(object) - buildSmsParams 가 만든 params
// 반환값: object - pwd·commCode 가 '***' 로 바뀐 얕은 복사본
function redactParams(params) {
  if (!params || typeof params !== 'object') return {};
  const copy = { ...params };
  if ('commCode' in copy) copy.commCode = '***';
  if ('pwd' in copy) copy.pwd = '***';
  return copy;
}

// [parseSendResponse] - 접수 응답 본문을 해석한다 (returnType=3 기준)
// 파라미터: responseText(string) - 응답 본문
// 반환값: {ok: boolean, indexCode: string|null, error: string|null, raw: string}
// @example
// parseSendResponse('SUCCESS:M2026-abc')  // {ok:true, indexCode:'M2026-abc', error:null, raw:'SUCCESS:M2026-abc'}
// parseSendResponse('FAIL')               // {ok:false, indexCode:null, error:'FAIL', raw:'FAIL'}
function parseSendResponse(responseText) {
  const raw = responseText === null || responseText === undefined ? '' : String(responseText).trim();
  if (raw.toUpperCase().startsWith('SUCCESS:')) {
    const code = raw.slice('SUCCESS:'.length).trim();
    return { ok: true, indexCode: code === '' ? null : code, error: null, raw };
  }
  // 비즈모아샷은 실패 상세를 안 준다("접수 실패"만). 원문을 그대로 남겨 나중에 홈페이지에서 대조한다.
  return { ok: false, indexCode: null, error: raw === '' ? '접수 실패 (응답 없음)' : raw, raw };
}

// [decodeResponseBody] - 응답 바이트를 글자로 바꾼다 (UTF-8 우선, 깨지면 EUC-KR 로 재시도)
// 파라미터: buffer(Buffer)
// 반환값: string
function decodeResponseBody(buffer) {
  const utf8 = buffer.toString('utf8');
  // UTF-8 로 못 읽는 바이트는 U+FFFD 로 바뀐다 → 그 경우 EUC-KR 판 응답으로 본다
  return utf8.includes('�') ? iconv.decode(buffer, 'euc-kr') : utf8;
}

// [postForm] - form-urlencoded POST 를 보내고 본문을 문자열로 돌려준다 (문자 발송 기본 전송기)
// 파라미터: url(string), params(object), timeoutMs(number) - 총 대기 시간
// 반환값: Promise<{status: number, text: string}>
// 예외: 네트워크 오류·시간 초과·응답 도중 끊김 시 Error 를 던진다. 어떤 경우에도 반드시 끝난다.
function postForm(url, params, timeoutMs) {
  const body = new URLSearchParams(params).toString(); // UTF-8 퍼센트 인코딩
  return postRaw(url, Buffer.from(body, 'utf8'), 'application/x-www-form-urlencoded; charset=utf-8', timeoutMs);
}

// 주소 조회(DNS) 실패 뒤 다시 묻기 전 기다리는 시간 (밀리초)
const DNS_RETRY_DELAY_MS = 1000;
// 다시 보낼 때 최소한 남아 있어야 하는 시간 (밀리초). 이보다 짧으면 다시 보내도 시간 초과로 끝날 뿐이라 하지 않는다
const MIN_RETRY_WINDOW_MS = 2000;

// [isDnsLookupError] - 발송 주소의 이름을 숫자 주소로 바꾸지 못한 오류인가 (EAI_AGAIN·ENOTFOUND 등)
//   이름을 못 찾으면 연결 자체를 시작하지 않으므로 비즈모아샷은 아무것도 받지 못했다 → 다시 보내도 중복 발송이 아니다
// 파라미터: err(Error)
// 반환값: boolean
function isDnsLookupError(err) {
  return Boolean(err) && err.syscall === 'getaddrinfo';
}

// [postRaw] - 바이트 본문을 POST 하고 응답을 문자열로 돌려준다 (문자=form, 알림톡=JSON 이 공유하는 바닥 전송기)
//   주소 조회(DNS)가 순간적으로 실패하면 1초 뒤 한 번만 다시 보낸다 (2026-10-30 운영: DNS 서버 1회 무응답 → 등하원 문자 1통 실패)
//   다시 보낼 때도 처음 정한 총 대기 시간 안에서만 기다린다. 그 밖의 오류(시간 초과·끊김 등)는 접수됐는지 모르므로 다시 보내지 않는다
// 파라미터: url(string), bodyBuffer(Buffer), contentType(string), timeoutMs(number) - 총 대기 시간
//           retryDelayMs(number, 선택) - 다시 보내기 전 기다리는 시간. 기본 1초 (테스트에서 줄인다)
// 반환값: Promise<{status: number, text: string}>
// 예외: 네트워크 오류·시간 초과·응답 도중 끊김 시 Error 를 던진다. 어떤 경우에도 반드시 끝난다.
async function postRaw(url, bodyBuffer, contentType, timeoutMs, retryDelayMs = DNS_RETRY_DELAY_MS) {
  const deadline = Date.now() + timeoutMs;
  try {
    return await postRawOnce(url, bodyBuffer, contentType, timeoutMs);
  } catch (err) {
    const remainingMs = deadline - Date.now() - retryDelayMs;
    if (!isDnsLookupError(err) || remainingMs < MIN_RETRY_WINDOW_MS) throw err;
    console.warn(`⚠️ 비즈모아샷 주소 조회 실패(${err.code || '알 수 없음'}) → ${retryDelayMs}ms 뒤 한 번 더 시도`);
    await new Promise((resolve) => setTimeout(resolve, retryDelayMs));
    try {
      return await postRawOnce(url, bodyBuffer, contentType, remainingMs);
    } catch (retryErr) {
      // 다시 보낸 요청이 연결도 못 한 채 시간이 다 됐다 = 여전히 아무것도 나가지 않음
      //   → 처음 주소 조회 오류(code 있음)로 알려, 알림톡 실패 시 문자로 대신 보내는 판단(kakao.js notSent)이 그대로 동작하게 한다
      if (retryErr && retryErr.beforeConnect) {
        console.warn(`⚠️ 비즈모아샷 주소 조회 재시도도 연결 전 시간 초과 → 처음 오류(${err.code || '알 수 없음'})로 처리`);
        throw err;
      }
      throw retryErr;
    }
  }
}

// [postRawOnce] - postRaw 의 한 번 보내기 (다시 보내기 없음)
// 파라미터·반환값·예외: postRaw 와 같다
function postRawOnce(url, bodyBuffer, contentType, timeoutMs) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let timer = null;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      fn(value);
    };

    let target;
    try {
      target = new URL(url);
    } catch (err) {
      finish(reject, new Error(`발송 주소가 올바르지 않습니다: ${url}`));
      return;
    }
    const client = target.protocol === 'http:' ? http : https;
    // 응답 객체를 받은 뒤에는 응답 쪽('end'/'close') 이벤트만 믿는다.
    // 요청 쪽 'close' 가 응답 'end' 보다 먼저 와서 성공을 실패로 뒤집는 일을 Node 버전과 무관하게 막는다.
    let responseStarted = false;

    const req = client.request(
      {
        hostname: target.hostname,
        port: target.port || undefined,
        path: `${target.pathname}${target.search}`,
        method: 'POST',
        headers: {
          'Content-Type': contentType,
          'Content-Length': bodyBuffer.length,
          'User-Agent': 'NewGaon Moashot Client 0.2'
        }
      },
      (res) => {
        responseStarted = true;
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => finish(resolve, { status: res.statusCode || 0, text: decodeResponseBody(Buffer.concat(chunks)) }));
        res.on('error', (err) => finish(reject, err));
        // 서버가 본문을 보내다 연결을 끊으면 'end' 없이 'close' 만 온다 → 여기서 반드시 끝낸다
        res.on('close', () => {
          if (!res.complete) finish(reject, new Error('응답 도중 연결이 끊겼습니다.'));
        });
      }
    );
    // 업체 서버와 연결이 맺어졌는지 (연결 전 시간 초과 = 요청이 나가지 않음 → postRaw 가 다시 보낸 뒤 판단에 쓴다)
    let connected = false;
    req.on('socket', (socket) => {
      if (!socket.connecting) { connected = true; return; } // 이미 열린 연결을 다시 쓰는 경우
      socket.once('connect', () => { connected = true; });
    });
    req.on('error', (err) => finish(reject, err));
    req.on('close', () => {
      // 응답이 아직 시작되지 않았는데 닫혔다 = 요청 자체가 실패. 응답이 시작됐으면 res 쪽 이벤트가 마무리한다.
      if (!responseStarted) finish(reject, new Error('요청이 완료되기 전에 연결이 닫혔습니다.'));
    });

    // 총 대기 시간 제한. req.setTimeout 은 "가만히 있는 시간" 기준이라 찔끔찔끔 오는 응답을 못 막으므로 따로 건다.
    timer = setTimeout(() => {
      const err = new Error(`요청 시간 초과 (${Math.round(timeoutMs / 1000)}초)`);
      err.beforeConnect = !connected;
      finish(reject, err);
      req.destroy(err);
    }, timeoutMs);

    req.write(bodyBuffer);
    req.end();
  });
}

// 시험·개발용으로 http 를 허용하는 내 컴퓨터 주소 (URL.hostname 기준 — IPv6 는 대괄호 포함)
const LOOPBACK_HOSTS = Object.freeze(['127.0.0.1', 'localhost', '[::1]']);

// [isSecureSendUrl] - 비밀번호를 실어 보내도 되는 발송 주소인가 (https, 또는 내 컴퓨터의 http)
// 파라미터: url(string)
// 반환값: boolean - 주소 형식이 이상하면 false (발송하지 않는 쪽이 안전)
function isSecureSendUrl(url) {
  try {
    const target = new URL(url);
    if (target.protocol === 'https:') return true;
    return target.protocol === 'http:' && LOOPBACK_HOSTS.includes(target.hostname);
  } catch (_) {
    return false;
  }
}

// [sendSms] - 문자 1건(또는 같은 내용 여러 명)을 접수한다
// 파라미터: input(object) - buildSmsParams 와 동일
//           options.sendUrl(string)   - 발송 주소. 🔴 반드시 넘길 것. 없거나 빈 값이면 발송하지 않고 실패로 돌려준다
//                                       (실제 서버로 보내려면 moashot.DEFAULT_SEND_URL 을 명시적으로 넘긴다)
//           options.timeoutMs(number) - 총 대기 시간. 기본 10초
//           options.transport(function) - (url, params, timeoutMs) → Promise<{status, text}>. 테스트에서 가짜로 바꿔 끼운다
// 반환값: Promise<{
//   ok: boolean,               // 접수 성공 여부 (전송 성공이 아님 — 결과는 콜백으로)
//   indexCode: string|null,    // 첫 수신자의 접수ID (이력 저장용)
//   indexCodes: string[],      // 수신자별 접수ID 전부
//   isShort: boolean,          // 단문이면 true
//   byteLength: number,        // EUC-KR 바이트 수
//   raw: string,               // 응답 원문 (실패 대조용)
//   error: string|null         // 실패 사유 (한글)
// }>
// 예외를 던지지 않는다. 어떤 문제든 {ok:false, error} 로 돌려준다.
async function sendSms(input, options = {}) {
  let built;
  try {
    built = buildSmsParams(input);
  } catch (err) {
    return { ok: false, indexCode: null, indexCodes: [], isShort: true, byteLength: 0, raw: '', error: err.message };
  }
  const { params, meta } = built;
  const base = { indexCode: meta.indexCodes[0], indexCodes: meta.indexCodes, isShort: meta.isShort, byteLength: meta.byteLength };

  const sendUrl = typeof options.sendUrl === 'string' ? options.sendUrl.trim() : '';
  if (sendUrl === '') {
    return { ...base, ok: false, raw: '', error: '문자 발송 주소가 설정되지 않아 발송하지 않았습니다.' };
  }
  // 비밀번호를 그대로 싣고 가므로 https 가 아니면 보내지 않는다 (시험용 내 컴퓨터 주소만 예외)
  if (!isSecureSendUrl(sendUrl)) {
    // 원장 화면에는 조치 가능한 문구만, 설정 이름은 서버 로그에만 (검수 지적). 주소에는 비밀값이 없다
    console.error('⚠️ 비즈모아샷 문자 발송 주소가 https 가 아니어서 발송하지 않음 (비밀번호 보호) — 서버 설정 MOASHOT_SEND_URL 확인 필요');
    return { ...base, ok: false, raw: '', error: '문자 발송 설정에 문제가 있어 발송하지 않았습니다. 관리자에게 문의하세요.' };
  }

  const transport = typeof options.transport === 'function' ? options.transport : postForm;
  const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : DEFAULT_TIMEOUT_MS;

  try {
    const response = await transport(sendUrl, params, timeoutMs);
    const parsed = parseSendResponse(response && response.text);
    if (!parsed.ok) {
      const status = response && response.status ? ` (HTTP ${response.status})` : '';
      return { ...base, ok: false, raw: parsed.raw, error: `${parsed.error}${status}` };
    }
    // 응답의 indexCode 가 우리가 보낸 것과 다르면 이상 상황 — 발송은 됐으므로 성공으로 두되 원문을 남긴다
    return { ...base, ok: true, raw: parsed.raw, error: null };
  } catch (err) {
    return { ...base, ok: false, raw: '', error: err && err.message ? err.message : '문자 발송 중 오류가 발생했습니다.' };
  }
}

module.exports = {
  DEFAULT_SEND_URL,
  DEFAULT_TIMEOUT_MS,
  DNS_RETRY_DELAY_MS,
  MIN_RETRY_WINDOW_MS,
  getMd5Hex,
  isDnsLookupError,
  isSecureSendUrl,
  generateIndexCode,
  buildSmsParams,
  redactParams,
  parseSendResponse,
  decodeResponseBody,
  postForm,
  postRaw,
  sendSms
};
