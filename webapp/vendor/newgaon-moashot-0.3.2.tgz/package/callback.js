/**
 * [비즈모아샷 공용 모듈 — 결과 콜백 해석]
 * 파일: backend/lib/moashot/callback.js
 *
 * 비즈모아샷은 발송 후 우리 서버의 returnUrl 로 POST 를 보내 결과를 알려준다.
 *   nType=1 (접수)     : indexCode, title, toNumber, ErrMsg(실패 시)
 *   nType=2 (전송결과) : data, send_start, send_end, re_send
 *   nType=3            : 둘 다
 *
 * 🔴 함정 두 가지 (인수인계 3-3 · 3-5)
 *   1) data 는 여러 건이면 "접수ID,코드,접수ID,코드…" 로 계속 이어붙는다.
 *      → 콤마로 자른 뒤 앞에서부터 2개씩 짝지어 읽는다. 1건 기준으로 읽으면 첫 사람 것만 남는다.
 *   2) 시간 항목 이름이 매뉴얼 안에서도 Send_start / send_start 로 어긋난다.
 *      → 항목 이름을 전부 소문자로 바꾼 뒤 읽는다. 어느 쪽으로 오든 상관없다.
 *
 * 이 파일은 DB 를 모른다. 해석 결과를 돌려줄 뿐, 이력 갱신은 프로그램 쪽 몫이다.
 */

const { describeResultCode, CHANNEL_SMS } = require('./codes');

// [normalizeKeys] - 객체의 키를 전부 소문자로 바꾼다 (대소문자 함정 우회)
// 파라미터: body(object) - 요청 본문
// 반환값: object - 소문자 키 객체. 값은 문자열로 통일(배열이면 첫 값)
function normalizeKeys(body) {
  const out = Object.create(null); // 외부 입력이 키가 되므로 프로토타입 없는 객체를 쓴다
  if (!body || typeof body !== 'object') return out;
  for (const key of Object.keys(body)) {
    const raw = body[key];
    const value = Array.isArray(raw) ? raw[0] : raw;
    out[String(key).toLowerCase()] = value === null || value === undefined ? '' : String(value);
  }
  return out;
}

// [parseResultData] - data 항목("접수ID,코드,접수ID,코드…")을 건별 결과 배열로 푼다
// 파라미터: data(string) - 콜백의 data 값, channel(string) - 결과코드표 선택('sms'|'kakao')
// 반환값: Array<{indexCode: string, code: string, ok: boolean, reason: string}>
// @example
// parseResultData('A1,1,A2,46')  // [{indexCode:'A1',code:'1',ok:true,...},{indexCode:'A2',code:'46',ok:false,reason:'잔액 부족'}]
function parseResultData(data, channel = CHANNEL_SMS) {
  const text = data === null || data === undefined ? '' : String(data).trim();
  if (text === '') return [];
  // 빈 조각(",,A1,1" 처럼 앞뒤에 콤마가 더 붙은 경우)은 먼저 걸러낸다. 안 걸러내면 짝이 한 칸씩 밀린다.
  const parts = text.split(',').map((p) => p.trim()).filter((p) => p !== '');
  const results = [];
  // 앞에서부터 2개씩 짝지어 읽는다. 마지막에 홀로 남은 조각은 코드가 없는 것이므로 '없음' 으로 표시한다.
  for (let i = 0; i < parts.length; i += 2) {
    const indexCode = parts[i];
    const described = describeResultCode(parts[i + 1] === undefined ? '' : parts[i + 1], channel);
    results.push({ indexCode, code: described.code, ok: described.ok, reason: described.reason });
  }
  return results;
}

// [parseCallback] - 콜백 본문 전체를 해석한다
// 파라미터: body(object) - express 의 req.body (form-urlencoded 파싱 결과)
//           options.channel(string) - 결과코드표 선택. 기본 'sms'
// 반환값: {
//   type: number|null,                 // nType (1 접수 / 2 전송결과 / 3 둘다). 없으면 null
//   accepted: {indexCodes: string[], title: string, toNumber: string, errMsg: string}|null, // 접수 정보(nType 1·3)
//   results: Array<{indexCode, code, ok, reason}>,   // 전송결과(nType 2·3). 없으면 빈 배열
//   sendStart: string, sendEnd: string,              // 전송 시작·종료 시각 원문 (없으면 '')
//   reSend: boolean                                  // 알림톡 실패 → 문자 대체발송 여부
// }
function parseCallback(body, options = {}) {
  const channel = options.channel || CHANNEL_SMS;
  const b = normalizeKeys(body);

  const typeNumber = parseInt(b.ntype, 10);
  const type = Number.isNaN(typeNumber) ? null : typeNumber;

  // 접수 정보: indexCode 가 있을 때만. 여러 건이면 콤마 구분이므로 배열로 돌려준다.
  const hasAccepted = b.indexcode !== undefined && b.indexcode !== '';
  const accepted = hasAccepted
    ? {
      indexCodes: b.indexcode.split(',').map((s) => s.trim()).filter((s) => s !== ''),
      title: b.title || '',
      toNumber: b.tonumber || '',
      errMsg: b.errmsg || ''
    }
    : null;

  // 알림톡이 실패해 문자로 대체 발송된 경우(re_send=Y) 결과코드는 "문자" 코드표로 온다 (인수인계 3-4)
  const reSend = (b.re_send || '').toUpperCase() === 'Y';
  const codeChannel = reSend ? CHANNEL_SMS : channel;

  return {
    type,
    accepted,
    results: parseResultData(b.data, codeChannel),
    sendStart: b.send_start || '',
    sendEnd: b.send_end || '',
    reSend
  };
}

module.exports = {
  normalizeKeys,
  parseResultData,
  parseCallback
};
