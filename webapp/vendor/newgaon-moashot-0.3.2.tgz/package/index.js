/**
 * [비즈모아샷 공용 모듈 — 공개 진입점]
 * 파일: backend/lib/moashot/index.js
 *
 * 학원관리(LMS)·근태관리 두 프로그램이 같은 코드를 쓰기 위한 모듈이다.
 *   · DB, 화면, 환경변수를 전혀 모른다 → 계정·발송주소는 부르는 쪽이 넘긴다
 *   · 의존성은 iconv-lite 하나뿐
 *   · 알림톡(kakao.js): 템플릿 변수 치환·payload 조립·접수 (5단계, 2026-09-02)
 *
 * 사용 예 (LMS 어댑터 backend/utils/smsService.js 에서):
 *   const moashot = require('../lib/moashot');
 *   const r = await moashot.sendSms(
 *     { account: { id, password, sender }, to: '010-1234-5678', text: '[알림] 홍길동 학생이 등원하였습니다.' },
 *     { sendUrl: process.env.MOASHOT_SEND_URL || '' }   // 🔴 주소를 안 넘기면 발송하지 않는다 (실서버 오발송 방지)
 *   );
 *   // r.ok(접수 성공) / r.indexCode(이력에 저장) / r.error(한글 사유)
 *   // 실제 발송 주소는 운영 .env 에 MOASHOT_SEND_URL=moashot.DEFAULT_SEND_URL 값으로 넣는다
 */

const { version: VERSION } = require('./package.json');
const text = require('./text');
const codes = require('./codes');
const callback = require('./callback');
const sms = require('./sms');
const kakao = require('./kakao');

module.exports = {
  VERSION,

  // 알림톡 (5단계)
  sendKakao: kakao.sendKakao,
  buildKakaoPayload: kakao.buildKakaoPayload,
  parseKakaoResponse: kakao.parseKakaoResponse,
  renderTemplate: kakao.renderTemplate,
  extractTemplateVariables: kakao.extractTemplateVariables,
  validateButtons: kakao.validateButtons,
  DEFAULT_KAKAO_SEND_URL: kakao.DEFAULT_KAKAO_SEND_URL,
  ALLOWED_BUTTON_TYPES: kakao.ALLOWED_BUTTON_TYPES,

  // 발송
  sendSms: sms.sendSms,
  buildSmsParams: sms.buildSmsParams,
  redactParams: sms.redactParams,
  parseSendResponse: sms.parseSendResponse,
  postForm: sms.postForm,
  generateIndexCode: sms.generateIndexCode,
  DEFAULT_SEND_URL: sms.DEFAULT_SEND_URL,

  // 결과 콜백
  parseCallback: callback.parseCallback,
  parseResultData: callback.parseResultData,

  // 결과 코드
  describeResultCode: codes.describeResultCode,
  SMS_RESULT_CODES: codes.SMS_RESULT_CODES,
  KAKAO_RESULT_CODES: codes.KAKAO_RESULT_CODES,
  SUCCESS_CODE: codes.SUCCESS_CODE,
  CHANNEL_SMS: codes.CHANNEL_SMS,
  CHANNEL_KAKAO: codes.CHANNEL_KAKAO,

  // 글자 처리 (화면 입력 차단·단문/장문 판정)
  findUnsupportedChars: text.findUnsupportedChars,
  isShortMessage: text.isShortMessage,
  getEuckrByteLength: text.getEuckrByteLength,
  stripPhone: text.stripPhone,
  isValidPhone: text.isValidPhone,
  isValidSenderPhone: text.isValidSenderPhone,
  maskPhone: text.maskPhone,
  MAX_SHORT_BYTES: text.MAX_SHORT_BYTES,
  MAX_LONG_BYTES: text.MAX_LONG_BYTES
};
