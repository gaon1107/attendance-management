/**
 * [비즈모아샷 공용 모듈 — 전송 결과 코드표]
 * 파일: backend/lib/moashot/codes.js
 *
 * 비즈모아샷이 결과 콜백(returnUrl)으로 알려주는 숫자 코드를 한글 사유로 바꾼다.
 * 출처: 비즈모아샷 전송결과코드표 PDF (문자 24개 · 알림톡 12개).
 *       2026-09-01 원본 대조 완료 — 인수인계 문서 3-4 절과 동일.
 * ⚠️ 대체문자(알림톡 실패 → 문자로 대신 발송, re_send=Y)의 결과는 "문자" 코드표로 온다.
 */

// 성공을 뜻하는 유일한 코드 (문자·알림톡 공통)
const SUCCESS_CODE = '1';

// 문자(SMS/LMS/MMS) 결과 코드 → 한글 사유
const SMS_RESULT_CODES = Object.freeze({
  '1': '전송성공',
  '4': '음영지역',
  '5': '전원 꺼짐',
  '7': '번호오류',
  '10': '비가입자·결번',
  '14': '번호이동 오류',
  '16': '수신거부(스팸판정)',
  '18': 'MMS 미지원 단말',
  '19': '기타 실패',
  '20': '사용불가 아이디',
  '21': '패스워드 오류',
  '22': '없는 아이디',
  '24': '발송번호 저장 오류',
  '25': '주소정보 생성 오류',
  '31': '전송취소',
  '32': '번호형식 오류',
  '33': '전송차단(스팸)',
  '34': '번호중복',
  '41': '파라미터 누락',
  '42': '파라미터 누락',
  '43': '파라미터 누락',
  '44': '파라미터 누락',
  '45': '발신번호 미인증',
  '46': '잔액 부족',
  '70': '서비스 이용 불가'
});

// 알림톡 결과 코드 → 한글 사유
const KAKAO_RESULT_CODES = Object.freeze({
  '1': '전송성공',
  '4': '발신프로필 없음',
  '5': '음영지역',
  '6': '유효하지 않은 번호',
  '31': '전송취소',
  '33': '전송차단',
  '34': '번호중복',
  '41': '템플릿 없음',
  '42': '템플릿 내용 불일치',
  '43': '버튼 내용 불일치',
  '51': '기타 오류',
  '61': '일별 중복 발송'
});

// 코드표를 고를 때 쓰는 채널 이름
const CHANNEL_SMS = 'sms';
const CHANNEL_KAKAO = 'kakao';

// [describeResultCode] - 결과 코드를 성공 여부 + 한글 사유로 바꾼다
// 파라미터: code(string|number) - 결과 코드, channel(string) - 'sms'(기본) 또는 'kakao'
// 반환값: {code: string, ok: boolean, reason: string}
// @example
// describeResultCode(1)            // {code:'1', ok:true,  reason:'전송성공'}
// describeResultCode('46')         // {code:'46', ok:false, reason:'잔액 부족'}
// describeResultCode(42, 'kakao')  // {code:'42', ok:false, reason:'템플릿 내용 불일치'}
// describeResultCode('99')         // {code:'99', ok:false, reason:'알 수 없는 결과코드(99)'}
function describeResultCode(code, channel = CHANNEL_SMS) {
  // 코드가 "01" 처럼 0이 앞에 붙어 와도 같은 코드로 본다
  const normalized = String(code === null || code === undefined ? '' : code).trim().replace(/^0+(?=\d)/, '');
  const table = channel === CHANNEL_KAKAO ? KAKAO_RESULT_CODES : SMS_RESULT_CODES;
  // ⚠️ 조회표 키가 외부 입력이므로 hasOwnProperty 로 확인한다 ('__proto__' 같은 값 방어)
  const reason = Object.prototype.hasOwnProperty.call(table, normalized)
    ? table[normalized]
    : `알 수 없는 결과코드(${normalized || '없음'})`;
  return { code: normalized, ok: normalized === SUCCESS_CODE, reason };
}

module.exports = {
  SUCCESS_CODE,
  SMS_RESULT_CODES,
  KAKAO_RESULT_CODES,
  CHANNEL_SMS,
  CHANNEL_KAKAO,
  describeResultCode
};
