/**
 * [비즈모아샷 공용 모듈 — 카카오 알림톡 발송]
 * 파일: backend/lib/moashot/kakao.js
 *
 * 규격 출처: 비즈모아샷 카카오알림톡(접수) 매뉴얼 + 이용가이드 (인수인계 문서 3-2 · 7장)
 *   POST https://biz.moashot.com/ext/api/sendTalk.asp   (JSON)
 *   응답: HTTP 상태/JSON 코드 200=접수완료, 405 데이터 없음, 412 필수 누락, 414 POST 아님, 415 Content-Type, 416 건수 초과, 500 기타
 *
 * 🔴 지켜야 할 것 (인수인계 3-5 함정 3~6)
 *   · 비밀번호는 commType=0 + pwd 평문. 알림톡은 commType=1(MD5) 을 받지 않는다
 *   · text 는 승인된 템플릿과 "변수 외 모든 글자" 가 같아야 한다 → renderTemplate 로만 만든다 (결과코드 42 방지)
 *   · templateTitle: 템플릿 강조 타이틀에 변수를 썼다면 반드시 보낸다 (안 보내면 #{학생명} 이 그대로 찍힌다)
 *   · buttons 는 템플릿과 순서·내용까지 같아야 하고 생략하지 않는다. 종류는 WL(웹링크)만 (AL/BK/MD 는 구버전 카톡 3018 실패)
 *   · re_send=Y 로 실패 시 문자 대체. re_text 는 EUC-KR 로 표현 가능한 글자만 (이모지 깨짐)
 *   · 접수 성공 ≠ 전송 성공. 결과는 콜백(callback.js)으로. 대체문자 결과는 "문자" 코드표로 온다
 *
 * ⚠️ 실물 검증 전 미확정: 접수 응답 JSON 의 정확한 항목 이름. parseKakaoResponse 는 code/resultCode/status 를 모두 본다.
 *
 * 이 파일은 DB·환경변수를 모른다. 계정·발신프로필키·템플릿은 부르는 쪽이 넘긴다.
 */

const { stripPhone, isValidPhone, isValidSenderPhone, findUnsupportedChars } = require('./text');
const { generateIndexCode, postRaw, isSecureSendUrl } = require('./sms');

// 알림톡 발송 주소. 부르는 쪽이 options.sendUrl 로 "명시적으로" 넘겨야 쓰인다 (없으면 발송하지 않는다 — 문자와 같은 규칙)
const DEFAULT_KAKAO_SEND_URL = 'https://biz.moashot.com/ext/api/sendTalk.asp';
const DEFAULT_TIMEOUT_MS = 10000;
// 한 번에 보낼 수 있는 최대 건수 (매뉴얼)
const MAX_MESSAGES_PER_REQUEST = 1000;
// 알림톡 본문 최대 글자 수 (이용가이드: 템플릿 내용 최대 1,000자)
const MAX_TEXT_LENGTH = 1000;
// 허용 버튼 종류 (구버전 카톡 호환 — 인수인계 3-2)
const ALLOWED_BUTTON_TYPES = Object.freeze(['WL']);
const MAX_BUTTONS = 5;
// 템플릿 변수 표기: #{학생명}. 전역(g) 정규식은 lastIndex 가 남아 .test() 결과가 호출마다 달라지므로,
// "남아 있는지" 검사에는 g 없는 HAS_TEMPLATE_VAR 를 쓴다 (검수 지적)
const TEMPLATE_VAR_PATTERN = /#\{([^{}]+)\}/g;
const HAS_TEMPLATE_VAR = /#\{[^{}]+\}/;
const INDEX_CODE_PATTERN = /^[A-Za-z0-9_-]{1,40}$/;

// [extractTemplateVariables] - 템플릿 문구 안의 변수 이름 목록
// 파라미터: content(string) - '#{학생명} 학생이 #{상태}하였습니다.'
// 반환값: string[] - ['학생명', '상태'] (중복 제거, 등장 순서)
function extractTemplateVariables(content) {
  const names = [];
  const seen = new Set();
  for (const m of String(content || '').matchAll(TEMPLATE_VAR_PATTERN)) {
    const name = m[1].trim();
    if (name && !seen.has(name)) { seen.add(name); names.push(name); }
  }
  return names;
}

// [renderTemplate] - 템플릿 문구의 변수를 값으로 바꾼다 (승인 문구와 글자 하나도 달라지지 않게, 이 함수로만 본문을 만든다)
// 파라미터: content(string) - 승인된 템플릿 문구, variables(object) - {학생명:'홍길동', ...}
// 반환값: string
// 예외: 템플릿에 있는 변수가 variables 에 없으면 Error (변수가 그대로 나가는 사고 방지)
function renderTemplate(content, variables) {
  const source = variables && typeof variables === 'object' ? variables : {};
  // 변수 이름이 외부 입력(템플릿 문구)에서 오므로 프로토타입 없는 조회표로 옮긴다 (#{constructor} 같은 이름 방어)
  const vars = Object.create(null);
  for (const key of Object.keys(source)) vars[key] = source[key];
  const missing = extractTemplateVariables(content).filter((name) => vars[name] === undefined || vars[name] === null);
  if (missing.length > 0) {
    throw new Error(`알림톡 템플릿 변수 값이 없습니다: ${missing.join(', ')}`);
  }
  return String(content || '').replace(TEMPLATE_VAR_PATTERN, (_, name) => String(vars[name.trim()]));
}

// [validateButtons] - 버튼 목록 검증·정리 (WL 만, 최대 5개, 이름·주소 필수)
// 파라미터: buttons(Array|undefined)
// 반환값: Array<{button_type, button_name, button_url, button_url2}> - 없으면 빈 배열
function validateButtons(buttons) {
  if (buttons === undefined || buttons === null) return [];
  if (!Array.isArray(buttons)) throw new Error('알림톡 버튼은 배열이어야 합니다.');
  if (buttons.length > MAX_BUTTONS) throw new Error(`알림톡 버튼은 최대 ${MAX_BUTTONS}개입니다.`);
  return buttons.map((b, i) => {
    const type = String((b && b.button_type) || 'WL').toUpperCase();
    if (!ALLOWED_BUTTON_TYPES.includes(type)) {
      throw new Error(`알림톡 버튼 ${i + 1}번: 종류 ${type} 은 쓸 수 없습니다 (웹링크 WL 만 허용 — 구버전 카톡 호환).`);
    }
    const name = String((b && b.button_name) || '').trim();
    const url = String((b && b.button_url) || '').trim();
    if (!name || !url) throw new Error(`알림톡 버튼 ${i + 1}번: 이름과 주소가 필요합니다.`);
    if (!/^https?:\/\/\S+$/i.test(url)) throw new Error(`알림톡 버튼 ${i + 1}번: 주소는 http/https 로 시작해야 합니다.`);
    const url2 = String((b && b.button_url2) || url).trim();
    return { button_type: type, button_name: name, button_url: url, button_url2: url2 };
  });
}

// [buildKakaoPayload] - 알림톡 발송 JSON 본문을 조립한다 (순수 함수, 네트워크 없음)
// 파라미터: input(object)
//   account.id / account.password(평문) / account.sender(발신번호)
//   senderKey(string)   - 카카오 발신프로필키 (40자)
//   templateCode(string)- 승인된 템플릿 코드
//   messages(Array)     - 최대 1,000건. 각 항목:
//       to(string) 수신번호 / text(string) 본문(renderTemplate 결과) / templateTitle(string, 선택) / indexCode(선택, 자동 생성)
//       fallbackText(string, 선택) - 있으면 re_send=Y + re_text (EUC-KR 표현 가능해야 함) / buttons(Array, 선택)
//   returnUrl(string, 선택) - 있으면 nType=3, 없으면 4 / subId(string, 선택) / reserveAt(string 14자리, 선택)
// 반환값: {payload: object, meta: {indexCodes: string[], recipients: string[]}}
// 예외: 입력이 잘못되면 Error (한글 메시지)
function buildKakaoPayload(input) {
  const { account, senderKey, templateCode, messages, returnUrl, subId, reserveAt } = input || {};
  if (!account || !account.id || !account.password || !account.sender) {
    throw new Error('알림톡 발송 계정(아이디·비밀번호·발신번호)이 설정되지 않았습니다.');
  }
  const sender = stripPhone(account.sender);
  if (!isValidSenderPhone(sender)) throw new Error('발신번호 형식이 올바르지 않습니다.');
  const key = String(senderKey || '').trim();
  if (!/^[A-Za-z0-9]{20,64}$/.test(key)) throw new Error('카카오 발신프로필키가 없거나 형식이 틀립니다 (영문·숫자, 보통 40자).');
  const code = String(templateCode || '').trim();
  if (!code || code.length > 50) throw new Error('알림톡 템플릿 코드가 없거나 너무 깁니다.');
  if (!Array.isArray(messages) || messages.length === 0) throw new Error('보낼 알림톡이 없습니다.');
  if (messages.length > MAX_MESSAGES_PER_REQUEST) throw new Error(`알림톡은 한 번에 최대 ${MAX_MESSAGES_PER_REQUEST}건입니다.`);
  if (reserveAt !== undefined && reserveAt !== null && reserveAt !== '' && !/^\d{14}$/.test(String(reserveAt))) {
    throw new Error('예약 시각은 YYYYMMDDHHmmss 14자리여야 합니다.');
  }
  const ret = returnUrl === undefined || returnUrl === null ? '' : String(returnUrl).trim();
  if (ret !== '' && !/^https?:\/\/\S+$/i.test(ret)) throw new Error('결과 콜백 주소는 http 또는 https 로 시작하는 주소여야 합니다.');

  const indexCodes = [];
  const recipients = [];
  const items = messages.map((m, i) => {
    const to = stripPhone(m && m.to);
    if (!isValidPhone(to)) throw new Error(`알림톡 ${i + 1}번: 수신 전화번호가 올바르지 않습니다.`);
    const text = m && typeof m.text === 'string' ? m.text : '';
    if (text.trim() === '') throw new Error(`알림톡 ${i + 1}번: 본문이 없습니다.`);
    if (text.length > MAX_TEXT_LENGTH) throw new Error(`알림톡 ${i + 1}번: 본문이 ${MAX_TEXT_LENGTH}자를 넘습니다.`);
    if (HAS_TEMPLATE_VAR.test(text)) throw new Error(`알림톡 ${i + 1}번: 본문에 치환되지 않은 변수(#{...})가 남아 있습니다.`);
    let indexCode = m && m.indexCode !== undefined && m.indexCode !== null && m.indexCode !== '' ? String(m.indexCode) : generateIndexCode();
    if (!INDEX_CODE_PATTERN.test(indexCode)) throw new Error('접수ID 는 영문·숫자·-·_ 로 40자 이내여야 합니다.');
    indexCodes.push(indexCode);
    recipients.push(to);

    const item = { indexCode, toNumber: to, text };
    if (m && typeof m.templateTitle === 'string' && m.templateTitle.trim() !== '') item.templateTitle = m.templateTitle.trim();
    if (m && typeof m.fallbackText === 'string' && m.fallbackText.trim() !== '') {
      const bad = findUnsupportedChars(m.fallbackText);
      if (bad.length > 0) throw new Error(`알림톡 ${i + 1}번: 대체문자에 문자로 보낼 수 없는 글자가 있습니다: ${bad.join(' ')}`);
      item.re_send = 'Y';
      item.re_text = m.fallbackText;
    }
    const buttons = validateButtons(m && m.buttons);
    if (buttons.length > 0) item.buttons = buttons;
    return item;
  });

  const payload = {
    uid: String(account.id),
    pwd: String(account.password), // 알림톡은 commType=1(MD5) 불가 → 평문. ⚠️ payload 를 로그에 찍지 말 것 (redactParams)
    commType: '0',
    fromNumber: sender,
    senderKey: key,
    template_code: code,
    nType: ret ? '3' : '4',
    messages: items
  };
  if (ret) payload.returnUrl = ret;
  if (subId) payload.subId = String(subId);
  if (reserveAt) payload.startTime = String(reserveAt);
  return { payload, meta: { indexCodes, recipients } };
}

// [parseKakaoResponse] - 접수 응답을 해석한다
// 파라미터: status(number) - HTTP 상태, text(string) - 본문(JSON 예상)
// 반환값: {ok: boolean, code: string|null, error: string|null, raw: string}
//   ⚠️ 응답 JSON 의 정확한 항목 이름은 실물 검증 전 미확정 → code / resultCode / status / result 를 모두 본다.
//   HTTP 200 이고 코드가 없거나 200 이면 접수 성공으로 본다. 그 외는 실패 + 원문 보존.
function parseKakaoResponse(status, text) {
  const raw = text === null || text === undefined ? '' : String(text).trim();
  let code = null;
  let message = null;
  try {
    const json = JSON.parse(raw);
    if (json && typeof json === 'object') {
      const c = json.code ?? json.resultCode ?? json.result_code ?? json.status ?? json.result;
      if (c !== undefined && c !== null) code = String(c);
      const m = json.message ?? json.msg ?? json.resultMessage ?? json.error;
      if (m !== undefined && m !== null) message = String(m);
    }
  } catch (_) {
    // JSON 이 아니면 원문만 남긴다
  }
  const codeOk = code === null || code === '200' || /^(success|ok)$/i.test(code);
  const ok = Number(status) === 200 && codeOk;
  if (ok) return { ok: true, code: code || '200', error: null, raw };
  const reason = message || raw || '접수 실패 (응답 없음)';
  return { ok: false, code, error: `${reason}${Number(status) && Number(status) !== 200 ? ` (HTTP ${status})` : ''}`, raw };
}

// [sendKakao] - 알림톡을 접수한다 (여러 건 가능)
// 파라미터: input(object) - buildKakaoPayload 와 동일
//           options.sendUrl(string) - 🔴 반드시 넘길 것. 없으면 발송하지 않는다 (moashot.DEFAULT_KAKAO_SEND_URL)
//           options.timeoutMs(number), options.transport(function(url, payloadObject, timeoutMs) → {status, text})
// 반환값: Promise<{ok, indexCode, indexCodes, channel:'kakao', raw, error, status, notSent}> - 예외를 던지지 않는다
//   status(number|null)  - 비즈모아샷 HTTP 상태 (응답이 없으면 null)
//   notSent(boolean)     - true 면 요청이 비즈모아샷에 닿기 전에 멈춤 = 확실히 접수 안 됨
//                          (조립 실패·주소 없음/형식 틀림·도메인 못 찾음·연결 거부). 문자로 대신 보내도 이중 발송이 아니다 (2026-09-28 검수)
async function sendKakao(input, options = {}) {
  let built;
  try {
    built = buildKakaoPayload(input);
  } catch (err) {
    return { ok: false, indexCode: null, indexCodes: [], channel: 'kakao', raw: '', error: err.message, status: null, notSent: true };
  }
  const base = { indexCode: built.meta.indexCodes[0], indexCodes: built.meta.indexCodes, channel: 'kakao' };
  const sendUrl = typeof options.sendUrl === 'string' ? options.sendUrl.trim() : '';
  if (sendUrl === '') {
    return { ...base, ok: false, raw: '', error: '알림톡 발송 주소가 설정되지 않아 발송하지 않았습니다.', status: null, notSent: true };
  }
  // 주소 형식을 보내기 전에 확인한다 (https:// 가 빠진 주소 등 — .env 오타로 전 학원 알림이 "결과 미확인" 으로 사라지는 것 방지)
  if (!isHttpUrl(sendUrl)) {
    return { ...base, ok: false, raw: '', error: `알림톡 발송 주소가 올바르지 않습니다: ${sendUrl}`, status: null, notSent: true };
  }
  // 알림톡은 비밀번호를 평문(pwd)으로 싣고 가므로 https 가 아니면 보내지 않는다 (문자와 같은 규칙, 시험용 내 컴퓨터 주소만 예외)
  //   요청을 보내기 전에 멈추므로 notSent=true → 호출처가 문자로 대신 보내도 이중 발송이 아니다 (대기 목록 Y51, 2026-10-03)
  if (!isSecureSendUrl(sendUrl)) {
    // 원장 화면에는 조치 가능한 문구만, 설정 이름은 서버 로그에만 (문자와 같은 방식). 주소에는 비밀값이 없다
    console.error('⚠️ 비즈모아샷 알림톡 발송 주소가 https 가 아니어서 발송하지 않음 (비밀번호 보호) — 서버 설정 MOASHOT_KAKAO_SEND_URL 확인 필요');
    return { ...base, ok: false, raw: '', error: '알림톡 발송 설정에 문제가 있어 발송하지 않았습니다. 관리자에게 문의하세요.', status: null, notSent: true };
  }
  const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : DEFAULT_TIMEOUT_MS;
  const transport = typeof options.transport === 'function'
    ? options.transport
    : (url, payload, ms) => postRaw(url, Buffer.from(JSON.stringify(payload), 'utf8'), 'application/json; charset=utf-8', ms);
  try {
    const response = await transport(sendUrl, built.payload, timeoutMs);
    const status = response && Number(response.status) ? Number(response.status) : null;
    const parsed = parseKakaoResponse(response && response.status, response && response.text);
    return { ...base, ok: parsed.ok, raw: parsed.raw, error: parsed.error, status, notSent: false };
  } catch (err) {
    // 도메인을 못 찾았거나(ENOTFOUND·EAI_AGAIN) 연결을 거부당했으면(ECONNREFUSED) 요청이 나가지 않았다.
    // 시간 초과·연결 끊김 등은 접수됐는지 모르므로 notSent=false
    const notSent = Boolean(err && PRE_CONNECT_ERROR_CODES.includes(err.code));
    return { ...base, ok: false, raw: '', error: err && err.message ? err.message : '알림톡 발송 중 오류가 발생했습니다.', status: null, notSent };
  }
}

// 요청이 서버에 닿기 전에 나는 통신 오류 코드 (이 경우 비즈모아샷은 아무것도 받지 못했다)
const PRE_CONNECT_ERROR_CODES = Object.freeze(['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED']);

// [isHttpUrl] - http:// 또는 https:// 로 시작하는 올바른 주소인지
// 파라미터: url(string)
// 반환값: boolean
function isHttpUrl(url) {
  try {
    const u = new URL(url);
    return (u.protocol === 'http:' || u.protocol === 'https:') && u.hostname !== '';
  } catch (_) {
    return false;
  }
}

module.exports = {
  DEFAULT_KAKAO_SEND_URL,
  MAX_MESSAGES_PER_REQUEST,
  MAX_TEXT_LENGTH,
  ALLOWED_BUTTON_TYPES,
  extractTemplateVariables,
  renderTemplate,
  validateButtons,
  buildKakaoPayload,
  parseKakaoResponse,
  sendKakao
};
